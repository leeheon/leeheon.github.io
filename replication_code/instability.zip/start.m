clear; clc;


tic;

t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:29*4);
time       = t; 

m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;
uscy       = xlsread('data.csv',1, 'J54:J169');






nN=length(m1sy);

for k=1:length(m1sy)
logm1sy(k)=log(m1sy(k));

logir(k)=log(ir(k));
end
logir=logir' ;
Y1=logm1sy ;

X1 = [ones(length(ir),1) ir];

X2 = [ones(length(logir),1) logir];

be_hat= X1\Y1' ;
semi_elasticity_md    = be_hat(2)

be_hat2= X2\Y1' ;
elasticity_md    = be_hat2(2) 




mm1y=mean(m1sy ) 
muscy=mean(uscy ) 
target_1=mm1y;
target_2=elasticity_md;
target_3=muscy;

NN=100;
nir=linspace(0.004,0.16);  
for t=1:length(nir)
lognir(t)=log(nir(t)) ; 
logm1sy_hat(t)=be_hat(1)+be_hat(2)*nir(t) ;
m1sy_hat(t)=exp(logm1sy_hat(t)) ;


logm1sy_hat2(t)=be_hat2(1)+be_hat2(2)*lognir(t) ;
m1sy_hat2(t)=exp(logm1sy_hat2(t)) ;
end

clearvars -except elasticity_md mm1y muscy target_1 target_2 target_3





global  alpha sigma chi rho r  mu  qstar eta  B C  A ;

%%
m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;

rratio       = xlsread('data.csv',1, 'H54:H169'); 
time       = xlsread('data.csv',1, 'A54:A169');



nN=length(m1sy);



chi=mean(rratio) ;



x0=[0.01;1;0.9];



r=mean(ir) ;


options = optimoptions('fmincon','Display','off');
[x,fval]=fmincon('objfun',x0,[],[],[],[],[0;0;0],[0.01;5;3],'constraint_model_1',options);

B=3;
C=x(2);
eta=x(3);
sigma=0.5;
A=1;
alpha=A*(1-sigma) ;



q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
%dq=(-chi/(alpha*eta*C*(1-sigma+sigma*chi))^2)*((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-(1+eta)/eta);

dq= -chi*q^(eta+1)/(C*eta*alpha*(1-sigma+sigma*chi));

u=C*(q^(1-eta))/(1-eta);
z=q;
L=q/(alpha*sigma*q+B);
Z=z/(alpha*sigma*q+B);
elasmd=r*dq*(B/q)/(alpha*sigma*q+B)
semielasmd= dq*(B/q)/(alpha*sigma*q+B)
avgm1=Z



nir=linspace(0.0001,0.16);  ;
for t=1:length(nir)
%nir(t)=0.16-(0.16*(t))/100+0.005 ;
q=((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
Z=q/(alpha*sigma*q+B);
Zp1(t)=Z;
MBp(t)= Z *sigma*chi/( 1-sigma+sigma*chi ); 

end

m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;
mby       = xlsread('data.csv',1, 'J54:J169'); 
time       = xlsread('data.csv',1, 'A54:A169');


h = figure;
scatter(ir*100,m1sy,'o','LineWidth',3) ; %ylim([0 0.55])
ylim([0.12 0.18]) ;
xlim([0 16]) ;
hold on ;
plot(nir*100,Zp1,'k-','LineWidth',3) ;
xlabel('Nominal Interest Rate','FontSize',15,'interpreter','latex') ;
ylabel('$z/y$','FontSize',15,'interpreter','latex') ;
hp = legend('Data (1980Q1-2008Q4)','Model 1','Location','NorthEast') ;
set(hp,'FontSize',13);
%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'md3','-dpdf','-r0');



qstar=C^(1/eta)  ;


nirm=linspace(0.001,0.16,200);
ir=nirm;
for i=1:length(ir)
   


chi_m_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^2-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
chi_m(i)=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+ir(i)));
chi_m_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^3-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
p11(i)=1 ;



end

fig = figure;
area(nirm,p11,'FaceColor',[0.95    0.95    1],'HandleVisibility','off')
hold on;
area(nirm,chi_m_bar,'FaceColor',[0.8 0.8 1],'HandleVisibility','off')
hold on;
area(nirm,chi_m,'FaceColor',[0.8 0.8 1],'HandleVisibility','off')
hold on;
area(nirm,chi_m_hat,'FaceColor',[0.6510    0.7451    1.0000],'HandleVisibility','off')
hold on;
plot(nirm,chi_m_bar,'r-','LineWidth',6)
hold on;
plot(nirm,chi_m,'k-.','LineWidth',3)
hold on;
plot(nirm,chi_m_hat,'b-.','LineWidth',5)
hold on;
text(0.06,0.037,'$A_1$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.023,'$A_2$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.01,'$A_3$','FontSize',26,'Interpreter','latex')

legend({'$\bar{\chi}_m$','$\chi_m$','$\hat{\chi}_m$'},'FontSize',20,'Location','Northeast','Interpreter','latex')
xlabel('$i $','FontSize',14,'Interpreter','latex')
ylabel('$\chi $','FontSize',14,'Interpreter','latex')

ylim([0 0.05])
xlim([0.005 0.13])


set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'thres_1','-dpdf','-r0')

gap=chi_m-chi_m_bar;

%%

clearvars -except Zp1 A B  C eta sigma  alpha  qstar target_1 target_2 target_3

ir         = xlsread('data.csv',1, 'B54:B181');   ir=ir/100;
rratio       = xlsread('data.csv',1, 'H54:H181'); 


t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:32*4);
time       = t; 



for i=1:length(ir)
chi_m_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^2-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
chi_m(i)=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+ir(i)));
chi_m_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^3-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
end
%%
h=figure;
 plot(t,chi_m_bar,'r-','LineWidth',4) ; xtickformat("yyyyQQQ") ;
 hold on;
  plot(t,chi_m,'k-.','LineWidth',3) ;
 hold on;
  plot(t,chi_m_hat,'b-.','LineWidth',4) ;
 hold on;
  plot(t,rratio,'LineWidth',4) ; 
   
legend('$\bar{\chi}_m$','$\chi_m$','$\hat{\chi}_m$','$\chi$','Interpreter','latex','FontSize',15,'Location','Northeast')




set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_mt','-dpdf','-r0');


%%

clc;
clearvars -except Zp1 target_1 target_2 target_3;


global  alpha sigma chi rho r  mu  qstar eta  B C  A;
m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;

rratio       = xlsread('data.csv',1, 'H54:H169'); 
time       = xlsread('data.csv',1, 'A54:A169');


nN=length(m1sy);

rho=1/0.9709-1 ;

chi=mean(rratio) ;



x0=[0.01;1;0.9;0.052];
%chi=mrr_ratio ;
%chi=0.1548;
%chi=0.1464;
%sigma=0.5;



r=mean(ir) ;



options = optimoptions('fmincon','Display','off');
[x,fval]=fmincon('objfun',x0,[],[],[],[],[0;0;0;0],[0.01;5;3;1],'constraint_model_2',options);



B=3;
C=x(2);
eta=x(3);

mu=x(4);

sigma=0.5;
A=1;
alpha=A*(1-sigma) ;


q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);

dq= -chi*q^(eta+1)/(C*eta*alpha*(1-sigma+sigma*chi));

u=C*(q^(1-eta))/(1-eta);
uprime=C*(q^(-eta));
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=q-b;
Z=z/(alpha*sigma*q+B);

db= (mu*sigma*chi/(rho*(1-sigma+sigma*chi)) )*(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-2) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)  *( -q*(mu*sigma*chi/(rho*(1-sigma*sigma*chi))  ) )  ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)* ( (mu*sigma*alpha/rho)*(uprime-1) - r*mu*alpha*sigma/(rho*(1-sigma+sigma*chi)) )*dq  ;
dz=dq-db;
dZ =dz/(alpha*sigma*q+B) -dq*(z*alpha*sigma)/(B+alpha*sigma*q)^2 ;
elasmd=dZ *(r/Z)
avgm1=Z
avguscy=alpha*sigma*b/(alpha*sigma*q+B)



nir=linspace(0.0001,0.16);  ;
for t=1:length(nir)

q=((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=q-b;
Z=z/(alpha*sigma*q+B);
Zp2(t)=Z;

end

m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;
mby       = xlsread('data.csv',1, 'J54:J169'); 
time       = xlsread('data.csv',1, 'A54:A169');


h = figure;
scatter(ir*100,m1sy,'o','LineWidth',3) ; %ylim([0 0.55])
ylim([0.12 0.18]) ;
xlim([0 16]) ;
hold on ;
plot(nir*100,Zp1,'k-','LineWidth',3) ;
hold on ;
plot(nir*100,Zp2,'k--','LineWidth',3) ;
xlabel('Nominal Interest Rate','FontSize',15,'interpreter','latex') ;
ylabel('$z/y$','FontSize',15,'interpreter','latex') ;
hp = legend('Data (1980Q1-2008Q4)','Model 1','Model 2','Location','NorthEast') ;
set(hp,'FontSize',13);
%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'md','-dpdf','-r0');







qstar=C^(1/eta);
for t=1:length(ir)

chi_m_bar(t)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(t)))^(-eta))-1 )) / ((1+ir(t))^2-1-sigma*alpha*( (C *(qstar/(1+ir(t)))^(-eta))-1 ) );
chi_m(t)=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+ir(t)));
chi_m_hat(t)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(t)))^(-eta))-1 )) / ((1+ir(t))^3-1-sigma*alpha*( (C *(qstar/(1+ir(t)))^(-eta))-1 ) );
end


%%


B=3

sigma=0.5
A=1
alpha=A*(1-sigma) 
C=x(2)
eta=x(3)
mu=x(4)



qstar=C^(1/eta)  ;

nirm=linspace(0.001,0.16,200);
for i=1:200
   
%nirm(i)=0+(0.16*(i))/nM -1/nM+0.0001 ;
iota=max(nirm(i),rho);
chi_c_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^2-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
chi_c_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^3-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
p11(i)=1 ;



end

fig = figure;
area(nirm,p11,'FaceColor',[1.0000    0.9500    0.9500],'HandleVisibility','off')
hold on;
area(nirm,chi_c_bar,'FaceColor',[1.0000    0.8    0.8],'HandleVisibility','off')

hold on;
area(nirm,chi_c_hat,'FaceColor',[1.0000    0.6    0.6],'HandleVisibility','off')
hold on;
plot(nirm,chi_c_bar,'r-.','LineWidth',4)
hold on;
plot(nirm,chi_c_hat,'b-.','LineWidth',4)
hold on;
text(0.06,0.08,'$\tilde{A}_1$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.055,'$\tilde{A}_2$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.022,'$\tilde{A}_3$','FontSize',26,'Interpreter','latex')

legend({'$\bar{\chi}_c$','$\hat{\chi}_c$'},'FontSize',20,'Location','Northeast','Interpreter','latex')
xlabel('$i $','FontSize',14,'Interpreter','latex')
ylabel('$\chi $','FontSize',14,'Interpreter','latex')

ylim([0 0.1])
xlim([0.005 0.13])


set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'thres_2','-dpdf','-r0')


%%
clearvars -except Zp1 A B  C eta mu sigma  alpha  qstar rho target_1 target_2 target_3;
clc;

ir         = xlsread('data.csv',1, 'B54:B181');   ir=ir/100;
rratio       = xlsread('data.csv',1, 'H54:H181'); 


t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:32*4);
time       = t; 





for i=1:length(ir)
iota=max(ir(i),rho);
chi_c_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^2-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
chi_c_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^3-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
end

%%
h=figure;
 plot(t,chi_c_bar,'r-','LineWidth',4) ; xtickformat("yyyyQQQ") ;

 hold on;
  plot(t,chi_c_hat,'b-.','LineWidth',4) ;
 hold on;
  plot(t,rratio,'LineWidth',4) ; 
   
legend('$\bar{\chi}_c$','$\hat{\chi}_c$','$\chi$','Interpreter','latex','FontSize',15,'Location','Northeast')




set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_ct','-dpdf','-r0');
  
  
  