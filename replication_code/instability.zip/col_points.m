function k=col_points(a,b,n)

%Collocation points for capital

k=cos((2*(n:-1:1)-1)/(2*n)*pi);
k=(k+1)*(b-a)/2+a;