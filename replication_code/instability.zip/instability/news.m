
%% Money only %% chi=1
clear; clc;
% Set Parameters

chi=1;

B=3;
beta=0.9709;
rho=1/0.9709-1;
A = 0.910655827445000;
sigma =0.5;
eta =0.140875372250997;
alpha =(1-sigma);

qstar=(1/A)^(-1/eta);
ustar=A*(qstar^(1-eta))/(1-eta);


rf=0.02;
%Solve for final steady state 
zfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
%Solve for initial steady state 
ri=0.10;
zis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
tt=[1 2 3 4 5];
m=7;

nr=ri;
% Set delta=t1-t0
zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zfs)^(-eta)-1) +1);
for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zt(tt))^(-eta)-1) +1);
else
zt(tt+1)=(zt(tt)/(1+nr));
end
end

mn=m+3;

z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time];
h=figure;
plot(time,z,'-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$t$','FontSize',15,'interpreter','latex')
l = legend('$z_t$','Location','NorthWest');
set(l,'FontSize',14,'interpreter', 'latex')
legend({'$z_t$ ($\chi=100\%)$'},'FontSize',14,'Location','NorthWest','Interpreter','latex')
%title('$\chi=0.002$','FontSize',14,'interpreter', 'latex')
title('100% Reserve Requirement' )
%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'ts1','-dpdf','-r0')





%%

r=1+nr;
tend= 1000;
fizall=col_points(0,1,tend);
for k=1:tend
fizt(k) =fizall(k) ;
fiztp(k)=(1/r)*fizt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*(A*(fizt(k))^(-eta)-1)+1);
if fizt(k)>qstar
fiztpf(k)=(1/r)*fizt(k);
else
fiztpf(k)=fiztp(k);
end
end




h = figure;
plot(fizt,fizt,'b--','LineWidth',1)
hold on;
plot(fizt,fiztpf,'k-','LineWidth',2)
hold on;
plot(zfs,z(10),'ko','LineWidth',3)


xlim([0 0.45])
ylim([0 0.45])

text(0.12,1,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',15)
legend('$45^{o}$','$f(z_{t+1})$','$z_T$','Interpreter','latex','FontSize',13,'Location','Southeast')
ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$z_{t+1}$','FontSize',15,'interpreter','latex')

title('100% Reserve Requirement' )


%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];




h00X = [zt(1), zfs];          
h00Y = [zt(1), zt(1)];   
h00 = annotation('line',h00X,h00Y);
h00.Parent = gca;           
h00.LineWidth  = 2; 
h00.Color  = 'blue';  


h01X = [zt(1), zt(1)];          
h01Y = [zt(1), zt(2)];   
h01 = annotation('line',h01X,h01Y);
h01.Parent = gca;           
h01.LineWidth  = 2; 
h01.Color  = 'blue';  



h02X = [zt(1), zt(2)];          
h02Y = [zt(2), zt(2)]; 
h02 = annotation('line',h02X,h02Y);   
h02.Parent = gca;           
h02.LineWidth  = 2; 
h02.Color  = 'blue';  



h0 = annotation('line');  % store the arrow information in ha
h0.Parent = gca;           % associate the arrow the the current axes
h0.X = [zt(2), zt(2)];          % the location in data units
h0.Y = [zt(2), zt(3)];   
h0.LineWidth  = 2;   
h0.Color  = 'blue';  


h1 = annotation('line');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [zt(2), zt(3)];          % the location in data units
h1.Y = [zt(3), zt(3)];   
h1.LineWidth  = 2;   
h1.Color  = 'blue';  

h2 = annotation('line');  % store the arrow information in ha
h2.Parent = gca;           % associate the arrow the the current axes
h2.X = [zt(3), zt(3)];          % the location in data units
h2.Y = [zt(3), zt(4)];   
h2.LineWidth  = 2;
h2.Color  = 'blue';  

h3 = annotation('line');  % store the arrow information in ha
h3.Parent = gca;           % associate the arrow the the current axes
h3.X = [zt(3), zt(4)];          % the location in data units
h3.Y = [zt(4), zt(4)];   
h3.LineWidth  = 2;
h3.Color  = 'blue';  

h4 = annotation('line');  % store the arrow information in ha
h4.Parent = gca;           % associate the arrow the the current axes
h4.X = [zt(4), zt(4)];          % the location in data units
h4.Y = [zt(4), zt(5)];   
h4.LineWidth  = 2;
h4.Color  = 'blue';  

h5 = annotation('line');  % store the arrow information in ha
h5.Parent = gca;           % associate the arrow the the current axes
h5.X = [zt(4), zt(5)];          % the location in data units
h5.Y = [zt(5), zt(5)];   
h5.LineWidth  = 2;
h5.Color  = 'blue';  

h6 = annotation('line');  % store the arrow information in ha
h6.Parent = gca;           % associate the arrow the the current axes
h6.X = [zt(5), zt(5)];          % the location in data units
h6.Y = [zt(5), zt(6)];   
h6.LineWidth  = 2;
h6.Color  = 'blue';  



h7 = annotation('line');  % store the arrow information in ha
h7.Parent = gca;           % associate the arrow the the current axes
h7.X = [zt(5), zt(6)];          % the location in data units
h7.Y = [zt(6), zt(6)];   
h7.LineWidth  = 2;
h7.Color  = 'blue';  




h8 = annotation('line');  % store the arrow information in ha
h8.Parent = gca;           % associate the arrow the the current axes
h8.X = [zt(6), zt(6)];          % the location in data units
h8.Y = [zt(6), zt(7)];   
h8.LineWidth  = 2;
h8.Color  = 'blue';  

h9 = annotation('line');  % store the arrow information in ha
h9.Parent = gca;           % associate the arrow the the current axes
h9.X = [zt(6), zt(7)];          % the location in data units
h9.Y = [zt(7), zt(7)];   
h9.LineWidth  = 2;
h9.Color  = 'blue';  

h10 = annotation('line');  % store the arrow information in ha
h10.Parent = gca;           % associate the arrow the the current axes
h10.X = [zt(7), zt(7)];          % the location in data units
h10.Y = [zt(7), zt(8)];   
h10.LineWidth  = 2;
h10.Color  = 'blue';  


% h11 = annotation('line');  % store the arrow information in ha
% h11.Parent = gca;           % associate the arrow the the current axes
% h11.X = [zt(7), zis];          % the location in data units
% h11.Y = [zt(8), zt(8)];   
% h11.LineWidth  = 2;
% h11.Color  = 'blue';  



% h12 = annotation('line');  % store the arrow information in ha
% h12.Parent = gca;           % associate the arrow the the current axes
% h12.X = [zis, zis];          % the location in data units
% h12.Y = [zis, zt(8)];   
% h12.LineWidth  = 2;
% h12.Color  = 'blue';  

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'fun1','-dpdf','-r0')






%% Money only %% chi=0.02
clear; clc;
% Set Parameters

chi=0.02;

B=3;
beta=0.9709;
rho=1/0.9709-1;
A = 0.910655827445000;
sigma =0.5;
eta =0.140875372250997;
alpha =(1-sigma);


qstar=(1/A)^(-1/eta);
ustar=A*(qstar^(1-eta))/(1-eta);


rf=0.02;
%Solve for final steady state 
zfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
%Solve for initial steady state 
ri=0.10;
zis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
tt=[1 2 3 4 5];
m=7;

nr=ri;
% Set delta=t1-t0
zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zfs)^(-eta)-1) +1);
for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zt(tt))^(-eta)-1) +1);
else
zt(tt+1)=(zt(tt)/(1+nr));
end
end

mn=m+3;

z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time];
h=figure;
plot(time,z,'-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$t$','FontSize',15,'interpreter','latex')
l = legend('$z_t$','Location','NorthWest');
set(l,'FontSize',14,'interpreter', 'latex')
legend({'$z_t$ ($\chi=2\%)$'},'FontSize',14,'Location','NorthWest','Interpreter','latex')
%title('$\chi=0.002$','FontSize',14,'interpreter', 'latex')
title('2% Reserve Requirement' )
%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'ts2','-dpdf','-r0')




r=1+nr;
tend= 1000;
fizall=col_points(0,0.6,tend);
for k=1:tend
fizt(k) =fizall(k) ;
fiztp(k)=(1/r)*fizt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*(A*(fizt(k))^(-eta)-1)+1);
if fizt(k)>qstar
fiztpf(k)=(1/r)*fizt(k);
else
fiztpf(k)=fiztp(k);
end
end





h = figure;
plot(fizt,fizt,'b--','LineWidth',1)
hold on;
plot(fizt,fiztpf,'k-','LineWidth',2)
hold on;
plot(zfs,z(10),'ko','LineWidth',3)


xlim([0.46 0.52])
ylim([0.45 0.51])



legend('$45^{o}$','$f(z_{t+1})$','$z_T$','Interpreter','latex','FontSize',13,'Location','Southeast')
title('2% Reserve Requirement' )
%legend('$45^{o}$','$\chi=0.02$','$z$','$z$','Interpreter','latex','Color','FontSize',15,'Location','Southeast')

ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$z_{t+1}$','FontSize',15,'interpreter','latex')




%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];




h00X = [zt(1), zfs];          
h00Y = [zt(1), zt(1)];   
h00 = annotation('line',h00X,h00Y);
h00.Parent = gca;           
h00.LineWidth  = 2; 
h00.Color  = 'blue';  


h01X = [zt(1), zt(1)];          
h01Y = [zt(1), zt(2)];   
h01 = annotation('line',h01X,h01Y);
h01.Parent = gca;           
h01.LineWidth  = 2; 
h01.Color  = 'blue';  



h02X = [zt(1), zt(2)];          
h02Y = [zt(2), zt(2)]; 
h02 = annotation('line',h02X,h02Y);   
h02.Parent = gca;           
h02.LineWidth  = 2; 
h02.Color  = 'blue';  



h0 = annotation('line');  % store the arrow information in ha
h0.Parent = gca;           % associate the arrow the the current axes
h0.X = [zt(2), zt(2)];          % the location in data units
h0.Y = [zt(2), zt(3)];   
h0.LineWidth  = 2;   
h0.Color  = 'blue';  


h1 = annotation('line');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [zt(2), zt(3)];          % the location in data units
h1.Y = [zt(3), zt(3)];   
h1.LineWidth  = 2;   
h1.Color  = 'blue';  

h2 = annotation('line');  % store the arrow information in ha
h2.Parent = gca;           % associate the arrow the the current axes
h2.X = [zt(3), zt(3)];          % the location in data units
h2.Y = [zt(3), zt(4)];   
h2.LineWidth  = 2;
h2.Color  = 'blue';  

h3 = annotation('line');  % store the arrow information in ha
h3.Parent = gca;           % associate the arrow the the current axes
h3.X = [zt(3), zt(4)];          % the location in data units
h3.Y = [zt(4), zt(4)];   
h3.LineWidth  = 2;
h3.Color  = 'blue';  

h4 = annotation('line');  % store the arrow information in ha
h4.Parent = gca;           % associate the arrow the the current axes
h4.X = [zt(4), zt(4)];          % the location in data units
h4.Y = [zt(4), zt(5)];   
h4.LineWidth  = 2;
h4.Color  = 'blue';  

h5 = annotation('line');  % store the arrow information in ha
h5.Parent = gca;           % associate the arrow the the current axes
h5.X = [zt(4), zt(5)];          % the location in data units
h5.Y = [zt(5), zt(5)];   
h5.LineWidth  = 2;
h5.Color  = 'blue';  

h6 = annotation('line');  % store the arrow information in ha
h6.Parent = gca;           % associate the arrow the the current axes
h6.X = [zt(5), zt(5)];          % the location in data units
h6.Y = [zt(5), zt(6)];   
h6.LineWidth  = 2;
h6.Color  = 'blue';  



h7 = annotation('line');  % store the arrow information in ha
h7.Parent = gca;           % associate the arrow the the current axes
h7.X = [zt(5), zt(6)];          % the location in data units
h7.Y = [zt(6), zt(6)];   
h7.LineWidth  = 2;
h7.Color  = 'blue';  




h8 = annotation('line');  % store the arrow information in ha
h8.Parent = gca;           % associate the arrow the the current axes
h8.X = [zt(6), zt(6)];          % the location in data units
h8.Y = [zt(6), zt(7)];   
h8.LineWidth  = 2;
h8.Color  = 'blue';  

h9 = annotation('line');  % store the arrow information in ha
h9.Parent = gca;           % associate the arrow the the current axes
h9.X = [zt(6), zt(7)];          % the location in data units
h9.Y = [zt(7), zt(7)];   
h9.LineWidth  = 2;
h9.Color  = 'blue';  

h10 = annotation('line');  % store the arrow information in ha
h10.Parent = gca;           % associate the arrow the the current axes
h10.X = [zt(7), zt(7)];          % the location in data units
h10.Y = [zt(7), zt(8)];   
h10.LineWidth  = 2;
h10.Color  = 'blue';  


% h11 = annotation('line');  % store the arrow information in ha
% h11.Parent = gca;           % associate the arrow the the current axes
% h11.X = [zt(7), zis];          % the location in data units
% h11.Y = [zt(8), zt(8)];   
% h11.LineWidth  = 2;
% h11.Color  = 'blue';  



% h12 = annotation('line');  % store the arrow information in ha
% h12.Parent = gca;           % associate the arrow the the current axes
% h12.X = [zis, zis];          % the location in data units
% h12.Y = [zis, zt(8)];   
% h12.LineWidth  = 2;
% h12.Color  = 'blue';  




set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'fun2','-dpdf','-r0')








%% Money only %% chi=0.01
clear; clc;
% Set Parameters

chi=0.01;

B=3;
beta=0.9709;
rho=1/0.9709-1;
A = 0.910655827445000;
sigma =0.5;
eta =0.140875372250997;
alpha =(1-sigma);


qstar=(1/A)^(-1/eta);
ustar=A*(qstar^(1-eta))/(1-eta);


rf=0.02;
%Solve for final steady state 
zfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
%Solve for initial steady state 
ri=0.10;
zis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
tt=[1 2 3 4 5];
m=7;

nr=ri;
% Set delta=t1-t0
zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zfs)^(-eta)-1) +1);
for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(zt(tt))^(-eta)-1) +1);
else
zt(tt+1)=(zt(tt)/(1+nr));
end
end

mn=m+3;

z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=col_points(1,mn,mn);

time=[-1 0 time];
h=figure;
plot(time,z,'-o','LineWidth',3)
xlim([-1 v-2])
%ylim([0.44 0.63])

ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$t$','FontSize',15,'interpreter','latex')
l = legend('$z_t$','Location','NorthWest');
set(l,'FontSize',14,'interpreter', 'latex')
legend({'$z_t$ ($\chi=1\%)$'},'FontSize',14,'Location','NorthWest','Interpreter','latex')
%title('$\chi=0.002$','FontSize',14,'interpreter', 'latex')
title('1% Reserve Requirement' )

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'ts3','-dpdf','-r0')




r=1+nr;
tend= 1000;
fizall=col_points(0,0.7,tend);
for k=1:tend
fizt(k) =fizall(k) ;
fiztp(k)=(1/r)*fizt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*(A*(fizt(k))^(-eta)-1)+1);
if fizt(k)>qstar
fiztpf(k)=(1/r)*fizt(k);
else
fiztpf(k)=fiztp(k);
end
end


h = figure;
plot(fizt,fizt,'b--','LineWidth',1)
hold on;
plot(fizt,fiztpf,'k-','LineWidth',2)
hold on;
plot(zfs,z(10),'ko','LineWidth',3)

ylim([0.44 0.63])
xlim([0.44 0.63])

text(0.12,1,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',15)
legend('$45^{o}$','$f(z_{t+1})$','$z_T$','Interpreter','latex','FontSize',13,'Location','Southeast')
ylabel('$z_t$','FontSize',15,'interpreter','latex')
xlabel('$z_{t+1}$','FontSize',15,'interpreter','latex')
title('1% Reserve Requirement' )



%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];



h00X = [zt(1), zfs];          
h00Y = [zt(1), zt(1)];   
h00 = annotation('line',h00X,h00Y);
h00.Parent = gca;           
h00.LineWidth  = 1.3;   
h00.Color  = 'blue';  


h01X = [zt(1), zt(1)];          
h01Y = [zt(1), zt(2)];   
h01 = annotation('line',h01X,h01Y);
h01.Parent = gca;           
h01.LineWidth  = 1.3;   
h01.Color  = 'blue';  



h02X = [zt(1), zt(2)];          
h02Y = [zt(2), zt(2)]; 
h02 = annotation('line',h02X,h02Y);   
h02.Parent = gca;           
h02.LineWidth  = 1.3;   
h02.Color  = 'blue';  



h0 = annotation('line');  % store the arrow information in ha
h0.Parent = gca;           % associate the arrow the the current axes
h0.X = [zt(2), zt(2)];          % the location in data units
h0.Y = [zt(2), zt(3)];   
h0.LineWidth  = 1.3;     
h0.Color  = 'blue';  


h1 = annotation('line');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [zt(2), zt(3)];          % the location in data units
h1.Y = [zt(3), zt(3)];   
h1.LineWidth  = 1.3;     
h1.Color  = 'blue';  

h2 = annotation('line');  % store the arrow information in ha
h2.Parent = gca;           % associate the arrow the the current axes
h2.X = [zt(3), zt(3)];          % the location in data units
h2.Y = [zt(3), zt(4)];   
h2.LineWidth  = 1.3; 
h2.Color  = 'blue';  

h3 = annotation('line');  % store the arrow information in ha
h3.Parent = gca;           % associate the arrow the the current axes
h3.X = [zt(3), zt(4)];          % the location in data units
h3.Y = [zt(4), zt(4)];   
h3.LineWidth  = 1.3; 
h3.Color  = 'blue';  

h4 = annotation('line');  % store the arrow information in ha
h4.Parent = gca;           % associate the arrow the the current axes
h4.X = [zt(4), zt(4)];          % the location in data units
h4.Y = [zt(4), zt(5)];   
h4.LineWidth  = 1.3; 
h4.Color  = 'blue';  

h5 = annotation('line');  % store the arrow information in ha
h5.Parent = gca;           % associate the arrow the the current axes
h5.X = [zt(4), zt(5)];          % the location in data units
h5.Y = [zt(5), zt(5)];   
h5.LineWidth  = 1.3; 
h5.Color  = 'blue';  

h6 = annotation('line');  % store the arrow information in ha
h6.Parent = gca;           % associate the arrow the the current axes
h6.X = [zt(5), zt(5)];          % the location in data units
h6.Y = [zt(5), zt(6)];   
h6.LineWidth  = 1.3; 
h6.Color  = 'blue';  



h7 = annotation('line');  % store the arrow information in ha
h7.Parent = gca;           % associate the arrow the the current axes
h7.X = [zt(5), zt(6)];          % the location in data units
h7.Y = [zt(6), zt(6)];   
h7.LineWidth  = 1.3; 
h7.Color  = 'blue';  




h8 = annotation('line');  % store the arrow information in ha
h8.Parent = gca;           % associate the arrow the the current axes
h8.X = [zt(6), zt(6)];          % the location in data units
h8.Y = [zt(6), zt(7)];   
h8.LineWidth  = 1.3; 
h8.Color  = 'blue';  

h9 = annotation('line');  % store the arrow information in ha
h9.Parent = gca;           % associate the arrow the the current axes
h9.X = [zt(6), zt(7)];          % the location in data units
h9.Y = [zt(7), zt(7)];   
h9.LineWidth  = 1.3; 
h9.Color  = 'blue';  

h10 = annotation('line');  % store the arrow information in ha
h10.Parent = gca;           % associate the arrow the the current axes
h10.X = [zt(7), zt(7)];          % the location in data units
h10.Y = [zt(7), zt(8)];   
h10.LineWidth  = 1.3; 
h10.Color  = 'blue';  





set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'fun3','-dpdf','-r0')




