function [c,ceq]=constraint(x)
global  A B C alpha sigma eta chi rho r mu target_1 target_2 target_3;
rho=1/0.9709-1 ;

B=3;
C=x(2);
eta=x(3);

mu=x(4);

sigma=0.5;
A=1;
alpha=A*(1-sigma) ;


q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);

dq= -chi*q^(eta+1)/(C*eta*alpha*(1-sigma+sigma*chi));

u=C*(q^(1-eta))/(1-eta);
uprime=C*(q^(-eta));

b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;

z=q-b;
Z=z/(alpha*sigma*q+B);


db= (mu*sigma*chi/(rho*(1-sigma+sigma*chi)) )*(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-2) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)  *( -q*(mu*sigma*chi/(rho*(1-sigma*sigma*chi))  ) )  ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)* ( (mu*sigma*alpha/rho)*(uprime-1) - r*mu*alpha*sigma/(rho*(1-sigma+sigma*chi)) )*dq  ;


dz=dq-db;


dZ =dz/(alpha*sigma*q+B) -dq*(z*alpha*sigma)/(B+alpha*sigma*q)^2 ;




elasmd=dZ *(r/Z);


nir=linspace(0.0001,0.16);  ;
for t=1:length(nir)
qt=real(((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta));
ut=C*(qt^(1-eta))/(1-eta);
bt=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(ut-qt)- qt*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
zt=qt-bt;
Zt(t)=zt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) 



avgm1=Z;


avguscy=alpha*sigma*b/(alpha*sigma*q+B);


er2_elasmd=100*(elasmd- target_2)^2;





er2_avguscy=100*(avguscy-target_3)^2      ;

er2_avgm1=100*(avgm1-target_1)^2      ;


c3=[0-avguscy];
c2=[0+elasmd];
c1=[0-avgm1];


ceq1=-x(1)+er2_avgm1+er2_elasmd +er2_avguscy ;

c=[c1 c2 c3]; 

ceq=[ceq1 er2_avgm1 er2_elasmd  er2_avguscy];


