%% Money and Credit %%%  chi=1
clear
% Set Parameters

chi=1



beta=0.9709
rho=1/0.9709-1
A =  1.045180154681457
sigma = 0.1
eta   = 0.322224166699998
alpha=1-sigma
mu=0.135948669677028
B=3


qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)

%Solve for final steady state 
rf=0.02

qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
ri=0.10
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5]
m=7



nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1)

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt))
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3
q=[qis qis flip(qt) qfs qfs]
b=[bis bis flip(bt) bfs bfs]
z=[zis zis flip(zt) zfs zfs]
v=length(z)
time=linspace(1,mn,mn)

time=[-1 0 time]
h=figure
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','Southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=100\%$, $\mu=0.1359$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'news_c1','-dpdf','-r0')



%% Money and Credit %%%  chi=0.1
clear
% Set Parameters

chi=0.1


beta=0.9709
rho=1/0.9709-1
A =  1.045180154681457
sigma = 0.1
eta   = 0.322224166699998
alpha=1-sigma
mu=0.135948669677028
B=3




qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)

%Solve for final steady state 
rf=0.02

qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
ri=0.10
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5]
m=7



nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1)

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt))
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3;
q=[qis qis flip(qt) qfs qfs];
b=[bis bis flip(bt) bfs bfs];
z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time]
h=figure;
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=10\%$, $\mu=0.1359$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'news_c2','-dpdf','-r0');

