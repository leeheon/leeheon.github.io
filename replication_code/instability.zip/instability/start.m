clear; clc;


tic;

t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:29*4);
time       = t; 

m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;
uscy       = xlsread('data.csv',1, 'J54:J169');







for k=1:length(m1sy)
logm1sy(k)=log(m1sy(k));

logir(k)=log(ir(k));
end
logir=logir' ;
Y1=logm1sy ;

X1 = [ones(length(ir),1) ir];

X2 = [ones(length(logir),1) logir];

be_hat= X1\Y1' ;
semi_elasticity_md    = be_hat(2)

be_hat2= X2\Y1' ;
elasticity_md    = be_hat2(2) 



global  target_1 target_2 target_3 ;
mm1y=mean(m1sy ) 
muscy=mean(uscy ) 
target_1=mm1y;
target_2=elasticity_md;
target_3=muscy;

NN=100;
nir=linspace(0.004,0.16);  
for t=1:length(nir)
lognir(t)=log(nir(t)) ; 
logm1sy_hat(t)=be_hat(1)+be_hat(2)*nir(t) ;
m1sy_hat(t)=exp(logm1sy_hat(t)) ;


logm1sy_hat2(t)=be_hat2(1)+be_hat2(2)*lognir(t) ;
m1sy_hat2(t)=exp(logm1sy_hat2(t)) ;
end

clearvars -except elasticity_md mm1y muscy target_1 target_2 target_3





global  alpha sigma chi rho r  mu  qstar eta  B C  A ;


m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;

rratio       = xlsread('data.csv',1, 'H54:H169'); 
time       = xlsread('data.csv',1, 'A54:A169');


nN=length(m1sy);
chi=mean(rratio) ;



x0=[0.01;1;0.9];



r=mean(ir) ;


options = optimoptions('fmincon','Display','off');
[x,fval]=fmincon('objfun',x0,[],[],[],[],[0;0;0],[0.01;5;3],'constraint_model_1',options);

B=3;
C=x(2);
eta=x(3);
sigma=0.5;
A=1;
alpha=A*(1-sigma) ;



q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
z=q;
Z=z/(alpha*sigma*q+B);



nir=linspace(0.0001,0.16);  
for t=1:length(nir)
qt=((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
Zt(t)=qt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;

avgm1=Z
elasmd    = be_hat2(2) 







qstar=C^(1/eta)  ;


nirm=linspace(0.001,0.16,200);
ir=nirm;
for i=1:length(ir)
   


chi_m_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^2-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
chi_m(i)=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+ir(i)));
chi_m_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^3-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
p11(i)=1 ;



end


fig = figure;
area(nirm,p11,'FaceColor',[0.95    0.95    1],'HandleVisibility','off')
hold on;
area(nirm,chi_m_bar,'FaceColor',[0.8 0.8 1],'HandleVisibility','off')
hold on;
area(nirm,chi_m,'FaceColor',[0.8 0.8 1],'HandleVisibility','off')
hold on;
area(nirm,chi_m_hat,'FaceColor',[0.6510    0.7451    1.0000],'HandleVisibility','off')
hold on;
plot(nirm,chi_m_bar,'r-','LineWidth',6)
hold on;
plot(nirm,chi_m,'k-.','LineWidth',3)
hold on;
plot(nirm,chi_m_hat,'b-.','LineWidth',5)
hold on;
text(0.06,0.023,'$A_1$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.0135,'$A_2$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.005,'$A_3$','FontSize',26,'Interpreter','latex')

legend({'$\bar{\chi}_m$','$\chi_m$','$\hat{\chi}_m$'},'FontSize',20,'Location','Northeast','Interpreter','latex')
xlabel('$i $','FontSize',14,'Interpreter','latex')
ylabel('$\chi $','FontSize',14,'Interpreter','latex')

ylim([0 0.03])
xlim([0.005 0.13])


set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'thres_1','-dpdf','-r0')

gap=chi_m-chi_m_bar;

%%

clearvars -except Zp1 A B  C eta sigma  alpha  qstar target_1 target_2 target_3

ir         = xlsread('data.csv',1, 'B54:B181');   ir=ir/100;
rratio       = xlsread('data.csv',1, 'H54:H181'); 


t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:32*4);
time       = t; 



for i=1:length(ir)
chi_m_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^2-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
chi_m(i)=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+ir(i)));
chi_m_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 )) / ((1+ir(i))^3-1-sigma*alpha*( (C *(qstar/(1+ir(i)))^(-eta))-1 ) );
end
%%
h=figure;
 plot(t,chi_m_bar,'r-','LineWidth',4) ; xtickformat("yyyyQQQ") ;
 hold on;
  plot(t,chi_m,'k-.','LineWidth',3) ;
 hold on;
  plot(t,chi_m_hat,'b-.','LineWidth',4) ;
 hold on;
     hp=plot(t,rratio,'-','LineWidth',4) ; 
   hp.Color = [0.5 0.7 1];
legend('$\bar{\chi}_m$','$\chi_m$','$\hat{\chi}_m$','$\chi$','Interpreter','latex','FontSize',15,'Location','Northeast')




set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_mt','-dpdf','-r0');


%%

clc;
clearvars -except Zp1 target_1 target_2 target_3;


global  alpha sigma chi rho r  mu  qstar eta  B C  A;
m1sy       = xlsread('data.csv',1, 'E54:E169'); 
ir         = xlsread('data.csv',1, 'B54:B169');   ir=ir/100;

rratio       = xlsread('data.csv',1, 'H54:H169'); 
time       = xlsread('data.csv',1, 'A54:A169');




rho=1/0.9709-1 ;

chi=mean(rratio) ;



x0=[0.01;1;0.9;0.052];
x0=[0.01;1;0.2;0.052];
%chi=mrr_ratio ;
%chi=0.1548;
%chi=0.1464;
%sigma=0.5;



r=mean(ir) ;



options = optimoptions('fmincon','Display','off');
[x,fval]=fmincon('objfun',x0,[],[],[],[],[0;0;0;0],[0.01;5;3;1],'constraint_model_2',options);



B=3;
C=x(2);
eta=x(3);

mu=x(4);

sigma=0.5;
A=1;
alpha=A*(1-sigma) ;




nir=linspace(0.0001,0.16);  ;
for t=1:length(nir)
qt=real(((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta));
ut=C*(qt^(1-eta))/(1-eta);
bt=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(ut-qt)- qt*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
zt=qt-bt;
Zt(t)=zt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) ;


q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);


u=C*(q^(1-eta))/(1-eta);
uprime=C*(q^(-eta));
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=q-b;
Z=z/(alpha*sigma*q+B);
avgm1=Z
avguscy=alpha*sigma*b/(alpha*sigma*q+B)
elasmd    = be_hat2(2) 



B=3

sigma=0.1;
A=1
alpha=A*(1-sigma) 
C=x(2)
eta=x(3)
mu=x(4)



qstar=C^(1/eta)  ;

nirm=linspace(0.001,0.16,200);
for i=1:200
   
%nirm(i)=0+(0.16*(i))/nM -1/nM+0.0001 ;
iota=max(nirm(i),rho);
chi_c_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^2-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
chi_c_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^3-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
p11(i)=1 ;



end

fig = figure;
area(nirm,p11,'FaceColor',[1.0000    0.9500    0.9500],'HandleVisibility','off')
hold on;
area(nirm,chi_c_bar,'FaceColor',[1.0000    0.8    0.8],'HandleVisibility','off')

hold on;
area(nirm,chi_c_hat,'FaceColor',[1.0000    0.6    0.6],'HandleVisibility','off')
hold on;
plot(nirm,chi_c_bar,'r-.','LineWidth',4)
hold on;
plot(nirm,chi_c_hat,'b-.','LineWidth',4)
hold on;
text(0.06,0.16,'$\tilde{A}_1$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.101,'$\tilde{A}_2$','FontSize',26,'Interpreter','latex')
hold on;
text(0.06,0.045,'$\tilde{A}_3$','FontSize',26,'Interpreter','latex')

legend({'$\bar{\chi}_c$','$\hat{\chi}_c$'},'FontSize',20,'Location','Northeast','Interpreter','latex')
xlabel('$i $','FontSize',14,'Interpreter','latex')
ylabel('$\chi $','FontSize',14,'Interpreter','latex')

ylim([0 0.2])
xlim([0.005 0.13])


set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'thres_2','-dpdf','-r0')


%%
clearvars -except Zp1 A B  C eta mu sigma  alpha  qstar rho target_1 target_2 target_3 avgm1 avguscy elasmd ;
clc;

ir         = xlsread('data.csv',1, 'B54:B181');   ir=ir/100;
rratio       = xlsread('data.csv',1, 'H54:H181'); 


t1 = datetime(1979,10,1);
t2 = datetime(2013,1,1);
t = t1 + calquarters(1:32*4);
time       = t; 





for i=1:length(ir)
iota=max(ir(i),rho);
chi_c_bar(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^2-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
chi_c_hat(i)= ( (1-sigma)*alpha*( (C *(qstar/(1+iota))^(-eta))-1 )) / ((1+iota)^3-1-sigma*alpha*( (C *(qstar/(1+iota))^(-eta))-1 ) );
end

%%
h=figure;
 plot(t,chi_c_bar,'r-','LineWidth',4) ; xtickformat("yyyyQQQ") ;

 hold on;
  plot(t,chi_c_hat,'b-.','LineWidth',4) ;
 hold on;
  hp=plot(t,rratio,'-','LineWidth',4) ; 
   hp.Color = [0.5 0.7 1];
legend('$\bar{\chi}_c$','$\hat{\chi}_c$','$\chi$','Interpreter','latex','FontSize',15,'Location','Northeast')


ylim([0.02 0.20])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_ct','-dpdf','-r0');
  

  
  