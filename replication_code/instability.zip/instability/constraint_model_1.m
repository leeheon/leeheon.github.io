function [c,ceq]=constraint(x)
global  A B C alpha sigma eta chi rho r  target_1 target_2 ;

rho=1/0.9709-1 ;

B=3;
C=x(2);
eta=x(3);
sigma=0.5;
A=1;
alpha=A*(1-sigma) ;


q=((1/C)*(1+(r*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);

dq= -chi*q^(eta+1)/(C*eta*alpha*(1-sigma+sigma*chi));

u=C*(q^(1-eta))/(1-eta);


z=q;
L=q/(alpha*sigma*q+B);
Z=z/(alpha*sigma*q+B);
elasmd=r*dq*(B/q)/(alpha*sigma*q+B);
semielasmd= dq*(B/q)/(alpha*sigma*q+B);

semielasmb= dq*(B/q)/(alpha*sigma*q+B);

mb=q*(sigma*chi)/(1-sigma+sigma*chi) ;
mby=mb/(alpha*sigma*q+B);


avgmby=mby;
avgm1=Z;


chi_m=(alpha*eta*(1-sigma)) / (eta*(1-alpha*sigma)+(2-eta)*(1+r));



er2_avgm1=100*(avgm1-target_1)^2      ;








nir=linspace(0.0001,0.16);  
for t=1:length(nir)
qt=((1/C)*(1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
Zt(t)=qt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) 
    


er2_elasmd=100*(elasmd- target_2)^2;


c2=[0+dq];
c1=[0-avgm1];



ceq1=-x(1)+er2_avgm1+er2_elasmd  ;

c=[c1 c2]; 

ceq=[ceq1 er2_avgm1 er2_elasmd   ];


