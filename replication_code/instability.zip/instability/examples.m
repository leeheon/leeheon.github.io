%% Steady State

clear; clc;

r=1.2;


sigma=0.6; alpha=0.7; C=1;  eta=0.8;
%sigma=0.5; alpha=0.5; C=1;  eta=0.9;
%sigma=0.5; alpha=0.5; C=0.8488;  eta=0.2312;

chi1=1;
chi2=0.5;
chi3=0.2;
chi4=0.1;

tend= 200;
zall=linspace(0.000000000001,2,tend);
zstar=1;




for k=1:tend
zt(k) =zall(k) ;
ztp1(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi1)/(chi1))*alpha*((zt(k))^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k))^(-eta)-1)+1);
ztp3(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi3)/(chi3))*alpha*((zt(k))^(-eta)-1)+1);
ztp4(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi4)/(chi4))*alpha*((zt(k))^(-eta)-1)+1);
if zt(k)>1
ztpf1(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
ztpf3(k)=(1/r)*zt(k);
ztpf4(k)=(1/r)*zt(k);
else
ztpf1(k)=ztp1(k);
ztpf2(k)=ztp2(k);
ztpf3(k)=ztp3(k);
ztpf4(k)=ztp4(k);
end
end
%
h = figure;
plot(zt,zt,'g--','LineWidth',1)
hold on;
plot(zt,ztpf1,'k-','LineWidth',4)
hold on;
plot(zt,ztpf2,'b-.','LineWidth',3.5)
hold on;
plot(zt,ztpf3,'m:','LineWidth',3)
hold on;
plot(zt,ztpf4,'r--','LineWidth',3)

text(1.19,0.9,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
%text(0.75,0.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('45^{o}','100% Reserve Requirement','50% Reserve Requirement','20% Reserve Requirement','10% Reserve Requirement','Location','SouthEast')
ylabel('$z_{t}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{t+1}$','FontSize',13,'Interpreter','latex')
axis([0 1.7 0 1.7])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'mss1','-dpdf','-r0')



nir=linspace(0,0.4);
for t=1:length(nir)
r=nir(t);
z1(t)=((1/C)*(1+(r*chi1/(alpha*(1-sigma+sigma*chi1)))))^(-1/eta);
z2(t)=((1/C)*(1+(r*chi2/(alpha*(1-sigma+sigma*chi2)))))^(-1/eta);
z3(t)=((1/C)*(1+(r*chi3/(alpha*(1-sigma+sigma*chi3)))))^(-1/eta);
z4(t)=((1/C)*(1+(r*chi4/(alpha*(1-sigma+sigma*chi4)))))^(-1/eta);
end

h = figure;
plot(nir,z1,'k-','LineWidth',4)
hold on;
plot(nir,z2,'b-.','LineWidth',3.5)
hold on;
plot(nir,z3,'m:','LineWidth',3)
hold on;
plot(nir,z4,'r--','LineWidth',3)


%text(0.75,0.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('100% Reserve Requirement','50% Reserve Requirement','20% Reserve Requirement','10% Reserve Requirement','Location','Southwest')
ylabel('$z$','FontSize',13,'Interpreter','latex')
xlabel('$i$','FontSize',13,'Interpreter','latex')
%axis([0 0.2 0 1.1])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'mss2','-dpdf','-r0')



%% Two period cycle 1

clear; clc;





sigma=0.6; alpha=0.7; C=1;  eta=0.8;

im=10;


r=1.2;


chi=0.1;
chi2=0.5;

syms  z
eqn1 = z==((1/r)^2)*z*(((1-sigma+sigma*chi)/(chi))*alpha*(((1/r)*z)^(-eta)-1)+1);
eqns = [eqn1];
vars = [z];
[solz] = solve(eqns,vars);
z2 = double(solz);
z1=(1/r)*z2;


syms  zalter
eqn1 = zalter==((1/r)^2)*zalter*(((1-sigma+sigma*chi2)/(chi2))*alpha*(((1/r)*zalter)^(-eta)-1)+1);
eqns = [eqn1];
vars = [zalter];
[solz] = solve(eqns,vars);
z2a = double(solz);
z1a=(1/r)*z2a;


tend= 500;
%zall=col_points(0,2,tend);
zall=linspace(0,2,tend);

zstar=1;
for k=1:tend
zt(k) =zall(k) ;
ztp(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((zt(k))^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k))^(-eta)-1)+1);
if zt(k)>1
ztpf(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
else
ztpf(k)=ztp(k);
ztpf2(k)=ztp2(k);
end
end
%
h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(zt,ztpf2,'r--','LineWidth',3.5)
hold on;
plot(zt,ztpf,'k-','LineWidth',2)
hold on;
plot(ztpf2,zt,'r--','LineWidth',3.5)
hold on;
plot(ztpf,zt,'k-','LineWidth',2)
%text(0.6,1.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
text(1.4,0.6,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
text(0.75,0.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
%text(0.2,0.8,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('45^{o}','50% Reserve Requirement','10% Reserve Requirement','Location','NorthWest')
ylabel('$(z_{t+1},z_{t})$','FontSize',13,'Interpreter','latex')
xlabel('$(z_{t},z_{t+1})$','FontSize',13,'Interpreter','latex')
axis([0 2 0 2])


ha = annotation('arrow');  % store the arrow information in ha
ha.Parent = gca;           % associate the arrow the the current axes
ha.X = [z1, z1];          % the location in data units
ha.Y = [z1, z2];   
ha.LineWidth  = 1;          % make the arrow bolder for the picture
ha.HeadWidth  = 8;
ha.HeadLength = 8;

hb = annotation('arrow');  % store the arrow information in ha
hb.Parent = gca;           % associate the arrow the the current axes
hb.X = [z2, z1];          % the location in data units
hb.Y = [z1, z1];  
hb.LineWidth  = 1;          % make the arrow bolder for the picture
hb.HeadWidth  = 8;
hb.HeadLength = 8;

hc = annotation('arrow');  % store the arrow information in ha
hc.Parent = gca;           % associate the arrow the the current axes
hc.X = [z2, z2];          % the location in data units
hc.Y = [z2, z1];  
hc.LineWidth  = 1;          % make the arrow bolder for the picture
hc.HeadWidth  = 8;
hc.HeadLength = 8;

hd = annotation('arrow');  % store the arrow information in ha
hd.Parent = gca;           % associate the arrow the the current axes
hd.X = [z1, z2];          % the location in data units
hd.Y = [z2, z2];  

hd.LineWidth  = 1;          % make the arrow bolder for the picture
hd.HeadWidth  = 8;
hd.HeadLength = 8;
set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'cycle21','-dpdf','-r0')


%% Two period cycle 2

clear;


%chi=0.5
sigma=0.6;
alpha=0.7;
A=1;

im=10;

r=1.2;
eta=0.8;

chi=0.1;
chi2=0.5;

tend= 500;
%zall=col_points(0,1.5,tend);
zall=linspace(0,1.5,tend);

zstar=1;

for k=1:tend
zt(k) =zall(k) ;
ztp(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((zt(k))^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k))^(-eta)-1)+1);
if zt(k)>1
ztpf(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
else
ztpf(k)=ztp(k);
ztpf2(k)=ztp2(k);
end
ztpn(k)=(1/r)*ztpf(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((ztpf(k))^(-eta)-1)+1);
ztp2n(k)=(1/r)*ztpf2(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((ztpf2(k))^(-eta)-1)+1);

if ztpf(k)>1
ztpnf(k)=(1/r)*ztpf(k);
else
ztpnf(k)=ztpn(k);
end

if ztpf2(k)>1
ztp2nf(k)=(1/r)*ztpf2(k);
else
ztp2nf(k)=ztp2n(k);
end
end

%

h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztp2nf,zt,'r--','LineWidth',3.5)
hold on;
plot(ztpnf,zt,'k-','LineWidth',2)
text(0.45,0.95,'$z_{t}=f^2(z_{t+2})$','Interpreter','latex','Color','r','FontSize',12)
text(1.1,0.7,'$z_{t}=f^2(z_{t+2})$','Interpreter','latex','Color','k','FontSize',12)
legend('45^{o}','50% Reserve Requirement','10% Reserve Requirement','Location','NorthWest')
ylabel('$z_{t+2}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{t}$','FontSize',13,'Interpreter','latex')
axis([0 1.5 0 1.5])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'cycle22','-dpdf','-r0')



%%
%plot(zt,zt,'b--',ztpnf,zt,'k-',ztp2nf,zt,'r--','LineWidth',2)

%% Three period cycle 1



%chi=0.5
sigma=0.6;
alpha=0.7;
A=1;
theta=0.9;
im=10;
eta=0.7;



r=1.2;



chi=0.05;
chi2=0.5;

for k=1:tend
zt(k) =zall(k) ;
ztp(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((zt(k))^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k))^(-eta)-1)+1);
if zt(k)>1
ztpf(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
else
ztpf(k)=ztp(k);
ztpf2(k)=ztp2(k);
end
end


syms  z
eqn1 = z==((1/r)^3)*z*(((1-sigma+sigma*chi)/(chi))*alpha*(((1/r)^(2)*z)^(-eta)-1)+1);
eqns = [eqn1];
vars = [z];
[solz] = solve(eqns,vars);
z3 = double(solz);
z2=(1/r)*z3;
z1=(1/r)*z2;

%

h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztpf2,zt,'r--','LineWidth',3.5)
hold on;
plot(ztpf,zt,'k-','LineWidth',2)
text(1.2,0.75,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
text(0.6,0.9,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('45^{o}','50% Reserve Requirement','5% Reserve Requirement','Location','NorthWest')
axis([0.5 1.5 0.5 1.5])
ylabel('$z_{t+1}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{t}$','FontSize',13,'Interpreter','latex')
h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [z1, z1];          % the location in data units
h1.Y = [z1, z2];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h2 = annotation('arrow');  % store the arrow information in ha
h2.Parent = gca;           % associate the arrow the the current axes
h2.X = [z1, z2];          % the location in data units
h2.Y = [z2, z2];  
h2.LineWidth  = 1;          % make the arrow bolder for the picture
h2.HeadWidth  = 8;
h2.HeadLength = 8;

h3 = annotation('arrow');  % store the arrow information in ha
h3.Parent = gca;           % associate the arrow the the current axes
h3.X = [z2, z2];          % the location in data units
h3.Y = [z2, z3];  
h3.LineWidth  = 1;          % make the arrow bolder for the picture
h3.HeadWidth  = 8;
h3.HeadLength = 8;

h4 = annotation('arrow');  % store the arrow information in ha
h4.Parent = gca;           % associate the arrow the the current axes
h4.X = [z2, z3];          % the location in data units
h4.Y = [z3, z3];  
h4.LineWidth  = 1;          % make the arrow bolder for the picture
h4.HeadWidth  = 8;
h4.HeadLength = 8;


h5 = annotation('arrow');  % store the arrow information in ha
h5.Parent = gca;           % associate the arrow the the current axes
h5.X = [z3, z3];          % the location in data units
h5.Y = [z3, z1];
h5.LineWidth  = 1;          % make the arrow bolder for the picture
h5.HeadWidth  = 8;
h5.HeadLength = 8;

h6 = annotation('arrow');  % store the arrow information in ha
h6.Parent = gca;           % associate the arrow the the current axes
h6.X = [z3, z1];          % the location in data units
h6.Y = [z1, z1];
h6.LineWidth  = 1;          % make the arrow bolder for the picture
h6.HeadWidth  = 8;
h6.HeadLength = 8;

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'cycle31','-dpdf','-r0')


%% Three period cycle 2

clear;


%chi=0.5
sigma=0.6;
alpha=0.7;
A=1;
theta=0.9;
im=10;

r=1.2;
eta=0.7;




chi=0.5;
chi2=0.05;

tend= 500;
%zall=col_points(0,2,tend);
zall=linspace(0,2,tend);
zstar=1;

for k=1:tend
zt(k) =zall(k) ;
ztp(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((zt(k))^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k))^(-eta)-1)+1);
if zt(k)>1
ztpf(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
else
ztpf(k)=ztp(k);
ztpf2(k)=ztp2(k);
end
ztpn(k)=(1/r)*ztpf(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((ztpf(k))^(-eta)-1)+1);
ztp2n(k)=(1/r)*ztpf2(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((ztpf2(k))^(-eta)-1)+1);
if ztpf(k)>1
ztpnf(k)=(1/r)*ztpf(k);
else
ztpnf(k)=ztpn(k);
end

if ztpf2(k)>1
ztp2nf(k)=(1/r)*ztpf2(k);
else
ztp2nf(k)=ztp2n(k);
end


ztpnn(k)=(1/r)*ztpnf(k)*(((1-sigma+sigma*chi)/(chi))*alpha*((ztpnf(k))^(-eta)-1)+1);
ztp2nn(k)=(1/r)*ztp2nf(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((ztp2nf(k))^(-eta)-1)+1);
if ztpf(k)>1
ztpnnf(k)=(1/r)*ztpnf(k);
else
ztpnnf(k)=ztpnn(k);
end

if ztpf2(k)>1
ztp2nnf(k)=(1/r)*ztp2nf(k);
else
ztp2nnf(k)=ztp2nn(k);
end



end

%


h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztpnnf,zt,'r--','LineWidth',3.5)
hold on;
plot(ztp2nnf,zt,'k-','LineWidth',2)
text(1.3,0.65,'$z_{t}=f^3(z_{t+3})$','Interpreter','latex','Color','k','FontSize',12)
text(0.8,0.4,'$z_{t}=f^3(z_{t+3})$','Interpreter','latex','Color','r','FontSize',12)
legend('45^{o}','50% Reserve Requirement','5% Reserve Requirement','Location','NorthWest')
ylabel('$z_{t+3}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{t}$','FontSize',13,'Interpreter','latex')
axis([0 1.8 0 1.8])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'cycle32','-dpdf','-r0')


