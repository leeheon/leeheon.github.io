%%
clear; clc;
b=0.000000000000000000000;
chi=0.08;
sigma=0.6;
alpha_b=0.7;
A=1.2; 
theta=0.9;
im=10;


r=1.10;
eta=0.7;
q_star=A^(1/eta);

q_ss=((1/A)*(1+(r-1)*chi/(alpha_b*(1-sigma+sigma*chi))))^(-1/eta);


chi2=0.5;
tend= 500;
%zall=col_points(0,3.5,tend);
zall=linspace(0,3.5,tend);

for k=1:tend
zt(k) =zall(k) ;
ztp(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha_b*(A*(zt(k))^(-eta)-1)+1);
if zt(k)>q_star
ztpf(k)=(1/r)*zt(k);
else
ztpf(k)=ztp(k);
end
end




zf2=0.12;
zf1=1.2*1.2;
zf=1.2;
syms  z
eqn1 = z==(1/r)*zf2*(((1-sigma+sigma*chi)/(chi))*alpha_b*((zf2)^(-eta)-1)+1);

eqns = [eqn1];
vars = [z];
[solz] = solve(eqns,vars);
za = double(solz);


%%
h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztpf,zt,'k-','LineWidth',2)

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.2 , 1.2];          % the location in data units
h1.Y = [0   , 1.28];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.2 , 1.28];          % the location in data units
h1.Y = [1.28, 1.28];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.28, 1.28];          % the location in data units
h1.Y = [1.28, 1.41];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.28, 1.41];          % the location in data units
h1.Y = [1.41, 1.41];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.41, 1.41];          % the location in data units
h1.Y = [1.41, 1.56];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.41, 1.56];          % the location in data units
h1.Y = [1.56, 1.56];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;


h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.56, 1.56];          % the location in data units
h1.Y = [1.56, 1.71];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])


h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.56, 1.71];          % the location in data units
h1.Y = [1.71, 1.71];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.71, 1.71];          % the location in data units
h1.Y = [1.71, 1.89];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])


h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.71, 1.89];          % the location in data units
h1.Y = [1.89, 1.89];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.89, 1.89];          % the location in data units
h1.Y = [1.89, 2.07];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])


h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [1.89, 2.07];          % the location in data units
h1.Y = [2.07, 2.07];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])



h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [2.07, 2.07];          % the location in data units
h1.Y = [2.07, 0.61];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [2.07, 0.61];          % the location in data units
h1.Y = [0.61, 0.61];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.2 0 2.2])

h1 = annotation('arrow');  % store the arrow information in ha
h1.Parent = gca;           % associate the arrow the the current axes
h1.X = [0.61, 0.61];          % the location in data units
h1.Y = [0.61, 0.009];   
h1.LineWidth  = 1;          % make the arrow bolder for the picture
h1.HeadWidth  = 8;
h1.HeadLength = 8;
axis([0 2.5 0 2.5])


text(0.79,1.58,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',15)


legend('45^{o}','Location','NorthWest')

ylabel('$z_{t+1}$','FontSize',15,'Interpreter','latex')
xlabel('$z_{t}$','FontSize',15,'Interpreter','latex')

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'burst1','-dpdf','-r0')

%%
h = figure;
yy=[1.2 1.28 1.41 1.56 1.71 1.89 2.07 0.61 0.009 0.0000001  0];
yyt=[ 0   1    2    3    4    5    6   7     8    9        10];

ys=q_ss*ones(1,11);
plot(yyt,yy,'k-o','LineWidth',3)


hold on;
plot(yyt,ys,'b--','LineWidth',1)

l = legend('$z_t$','$z_{s}$','Location','NorthWest');
set(l,'FontSize',14,'interpreter', 'latex')

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'burst2','-dpdf','-r0')