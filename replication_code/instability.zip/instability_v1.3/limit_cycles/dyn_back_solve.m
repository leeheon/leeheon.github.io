function F = dyn_back_solve(x,zt1,bt1,qstar,nr,chi,beta,sigma,eta,alpha,mu,gamma) 

qt1=min(qstar,zt1+bt1);
zt=max(real(x(1)),0);
bt=max(real(x(2)),0);
qt=min(qstar,zt+bt);


 
F(1) = - zt+(zt1/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(qt1^(-eta)-1) +1) ; 
F(2) = - bt + beta*bt1+(chi*mu*sigma*(-gamma*zt+beta*zt1)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*((qt1^(1-eta))/(1-eta)-qt1) ; 