clear; clc;


% Parameters
n = 10000; % number of iterations
transient = 9000; % number of transient iterations
m=900;

chi_line=linspace(0.13,0.001,m);

rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);

sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;




qstar=(1)^(-1/eta);
ustar=(qstar^(1-eta))/(1-eta);



%Solve for steady state 

rf=(0.0579+1)^(1/4)-1;

options = optimoptions('fsolve','Display','off');

nr=rf;
gamma=(1+nr)/(1+rho);

for j = 1:m
chi=chi_line(j);
qfs=((1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*(((qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs);
zfs=qfs-bfs;
ztv(j,1)=zfs+zfs*0.001;
btv(j,1)=bfs+zfs*0.001;
for i = 1:n
zt1=ztv(j,i);
bt1=btv(j,i);
qt1=min(qstar,zt1+bt1);
%x0 = [zt1,bt1]; %x = fsolve(@dyn_back_solve,x0,options,zt1,bt1,qstar,nr,chi,beta,A,sigma,eta,alpha,mu,gamma) ;
zt=(zt1/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(qt1^(-eta)-1) +1) ; 
bt=beta*bt1+(chi*mu*sigma*(-gamma*zt+beta*zt1)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*((qt1^(1-eta))/(1-eta)-qt1) ; 
ztv(j,i+1)=max(real(zt),0);
btv(j,i+1)=max(real(bt),0);
    if i > transient
        bifurcation_z(j, i - transient) = ztv(j,i+1);
        bifurcation_b(j, i - transient) = btv(j,i+1);
    end 
end
end
%%
% Plotting the bifurcation diagram for x
fig=figure;
plot(chi_line*100, bifurcation_z, 'k.', 'MarkerSize', 1);
ax=gca;
set(gca,'Fontsize',12)
%ax.XLim = [0.01 0.1 ];
ax.XLim = [1 13 ];
set(gca,'XTick',(1:2:13));
set(gca, 'XDir','reverse')

xlabel('Reserve Requirement (%)');
ylabel('Money Real Balances');
title('Bifurcation Diagram of Fractional Reserve Banking');
%axis([min(chi_line) max(chi_line)   -0.71 -0.64]);

set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'bifurc_1','-dpdf','-r0')

%%

% Plotting the bifurcation diagram for x
fig=figure;
plot(chi_line*100, bifurcation_b, 'k.', 'MarkerSize', 1);
ax=gca;
set(gca,'Fontsize',12)
%ax.XLim = [0.01 0.1 ];
ax.XLim = [1 13 ];
set(gca,'XTick',(1:2:13));
set(gca, 'XDir','reverse')

xlabel('Reserve Requirement (%)');
ylabel('Unsecured Credit');
title('Bifurcation Diagram of Fractional Reserve Banking');
%axis([min(chi_line) max(chi_line)   -0.71 -0.64]);



set(fig,'Units','Inches');
pos = get(fig,'Position');
set(fig,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig,'bifurc_2','-dpdf','-r0')