%%
clear; clc;




m=300;
chi_line=linspace(0.2,0.0001,m);
for j=1:m
%chi=0.05;

chi=chi_line(j);

rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);

sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;


qstar=(1)^(-1/eta);
ustar=(qstar^(1-eta))/(1-eta);

%Solve for steady state 

rf=(0.0579+1)^(1/4)-1;

qfs=((1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*(((qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs);
zfs=qfs-bfs;
%Solve for initial steady state 
ri=0.05;
ri=(0.05+1)^(1/4)-1;
qis=((1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta) ;
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*(((qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis);
zis=qis-bis;





nr=rf;
gamma=(1+nr)/(1+rho);
% Set delta=t1-t0

num_iterations = 10000;
transient = 9000;
xx = zeros(2, num_iterations);
xx(:, 1) = [zfs; bfs];


zt1=zfs+zfs*0.01;
bt1=bfs+zfs*0.01;

options = optimoptions('fsolve','Display','off');

x0 = [0.1,0.1];
x = fsolve(@dyn_back_solve,x0,options,zt1,bt1,qstar,nr,chi,beta,sigma,eta,alpha,mu,gamma) ;

ztv(1)=xx(1,1);
btv(1)=xx(2,1);
for t = 1:num_iterations-1
zt1=ztv(t);
bt1=btv(t);
qt1=min(qstar,zt1+bt1);
%x = fsolve(@dyn_back_solve,x0,options,zt1,bt1,qstar,nr,chi,beta,A,sigma,eta,alpha,mu,gamma) ;
zt=(zt1/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(qt1^(-eta)-1) +1) ; 
bt=beta*bt1+(chi*mu*sigma*(-gamma*zt+beta*zt1)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*((qt1^(1-eta))/(1-eta)-qt1) ; 
ztv(t+1)=max(real(zt),0);
btv(t+1)=max(real(bt),0);
    if t > transient-1
        bifurcation_z(t - transient+1) = ztv(t+1);
        bifurcation_b(t - transient+1) = btv(t+1);
    end 
end
for t=1:num_iterations
tt(t)=t;
end
%{
fig1 = figure;
plot(tt, ztv(:))
fig2 = figure;
plot(tt, btv(:))
%}
for t=1:num_iterations-transient
ttb(t)=t;
end
bifurcation_z=flip(bifurcation_z);
bifurcation_b=flip(bifurcation_b);

%{
fig1 = figure;
plot(ttb, bifurcation_z)
fig2 = figure;
plot(ttb, bifurcation_b)
%}
lbz=log(bifurcation_z);
lbb=log(bifurcation_b);

[trend_lz,cyclical_lz] = hpfilter(lbz);
[trend_lb,cyclical_lb] = hpfilter(lbb);

stdz(j)=std(cyclical_lz);
stdb(j)=std(cyclical_lb);

end
%%
fig1 = figure;
plot(chi_line*100, stdz,'k-', 'LineWidth', 3);
ax=gca;
set(gca,'Fontsize',12) %ax.XLim = [0.01 0.1 ];
set(gca, 'XDir','reverse')
xlabel('Reserve Requirement (%)');
ylabel('Cyclical Volatility of Real Balances ($\sigma^c_{z,t}$)','FontSize',13.5,'interpreter','latex')



set(fig1,'Units','Inches');
pos = get(fig1,'Position');
set(fig1,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig1,'limitvol_1','-dpdf','-r0')


fig2 = figure;
plot(chi_line*100, stdb,'k-', 'LineWidth', 3);
ylim([0 0.001])
ax=gca;
set(gca,'Fontsize',12) %ax.XLim = [0.01 0.1 ];
set(gca, 'XDir','reverse')
xlabel('Reserve Requirement (%)');
ylabel('Cyclical Volatility of Unsecured Credit ($\sigma^c_{b,t}$)','FontSize',13.5,'interpreter','latex')%Reduce margin



set(fig2,'Units','Inches');
pos = get(fig2,'Position');
set(fig2,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(fig2,'limitvol_2','-dpdf','-r0')