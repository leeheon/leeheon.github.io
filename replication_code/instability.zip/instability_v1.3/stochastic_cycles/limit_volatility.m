clear; clc;

sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;

bnr=5.5103;
chi=0.0914;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz_all=std(cyclical_lz)

bnr=6.7980;
chi=0.1611;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz_70s=std(cyclical_lz)


bnr=8.4288;
chi=0.1081;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz_80s=std(cyclical_lz)


bnr=4.6858;
chi=0.0619;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz_90s=std(cyclical_lz)

bnr=2.1285; 
chi=0.0347;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz_00s=std(cyclical_lz)




frac_all=stdz_all/0.0315
frac_70s=stdz_70s/0.0269
frac_80s=stdz_80s/0.0402
frac_90s=stdz_90s/0.0288
frac_00s=stdz_00s/0.029



%%
clear; clc;

sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;



bnr=2.1285; 
chi=0.001;
limitcycle
lbz=log(bifurcation_z);
[trend_lz,cyclical_lz] = hpfilter(lbz);
stdz=std(cyclical_lz)


