clear; clc;

rrq=16.11; nir=6.80; 
sigmavz=0.0280;

subcode

stdz

%%
clear; clc;
rrq=10.81; nir=8.43;
sigmavz=0.0418;

subcode
stdz


%%
clear; clc;
rrq=6.19; nir=4.69; 
sigmavz=0.0299;

subcode
stdz


%%
clear; clc; 
rrq=3.47; nir=2.13;  
sigmavz=0.0299;

subcode
stdz
%%
clear; clc; 
rrq=9.14; nir=5.51;

sigmavz=0.0327;

subcode
stdz


%%
clear; clc; 
 nir=2.13;  
 rrq=1;
sigmavz=0.0299;

subcode
stdz
