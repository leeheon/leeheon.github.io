%%

clear; clc;


tic;


% Read data from 1976 to 2008
m1sy       = xlsread('datas.csv',1, 'H2:H34'); 
ir         = xlsread('datas.csv',1, 'E2:E34');   ir=ir/100;
uscy       = xlsread('datas.csv',1, 'G2:G34');
year       = xlsread('datas.csv',1, 'A2:A34');
cy     = xlsread('datas.csv',1, 'I2:I34'); 
rry    = xlsread('datas.csv',1, 'J2:J34'); 











for k=1:length(m1sy)
logm1sy(k)=log(m1sy(k));
logir(k)=log(ir(k));
end
logir=logir' ;
Y1=logm1sy ;

X1 = [ones(length(ir),1) ir];

X2 = [ones(length(logir),1) logir];

be_hat= X1\Y1' ;
semi_elasticity_md    = be_hat(2)

be_hat2= X2\Y1' ;
elasticity_md    = be_hat2(2) 



global  target_1 target_2 target_3 ;
mm1y=mean(m1sy ) 
muscy=mean(uscy ) 
target_1=mm1y;
target_2=elasticity_md;
target_3=muscy;

NN=100;
nir=linspace(0.004,0.16);  
for t=1:length(nir)
lognir(t)=log(nir(t)) ; 
logm1sy_hat(t)=be_hat(1)+be_hat(2)*nir(t) ;
m1sy_hat(t)=exp(logm1sy_hat(t)) ;

logm1sy_hat2(t)=be_hat2(1)+be_hat2(2)*lognir(t) ;
m1sy_hat2(t)=exp(logm1sy_hat2(t)) ;
end







rratio = rry./(m1sy-cy); 
clc;
clearvars -except Zp1 target_1 target_2 target_3 rratio ir  semi_elasticity_md elasticity_md elasticity_mdq ;


global   chi  mu  qstar eta   r Sqstar qstar;
qstar=1;

chi=mean(rratio) ;




r=mean(ir) ;
sigma=0.5;
rho=1/0.9709-1 ;
beta=0.9709;





x0 = [3;0.4;0.1];
x0 = [3;0.46;0.1];
fun = @cali_step_1;
options = optimoptions('fsolve','Display','off');
x = fsolve(fun,x0,options);

alpha=(1-sigma) ;


B=x(1)
B_y=B
eta=x(2)
mu=x(3)
q=(1+(r*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta);
q_y=q;
Y_y=B+alpha*sigma*q

Sqstar= (qstar^(1-eta))/(1-eta)-qstar;

if eta==1
u=log(q);
else
u=q^(1-eta)/(1-eta);
end
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=max(q-b,0);
Z=z/(alpha*sigma*q+B)
avguscy=alpha*sigma*b/(alpha*sigma*q+B);
nir=linspace(0.0001,0.16);  
for t=1:length(nir)
qt=real((1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta));
if eta==1
ut=log(qt);
else
ut=qt^(1-eta)/(1-eta);
end
bt=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(ut-qt)- qt*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
zt=qt-bt;
Zt(t)=zt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) ;
target_1f=Z;
target_2f=elasmd;
target_3f=avguscy;
alpha*sigma*q ;




syms chic z1 b1 b2
eqn1 = (1+r)^2==(((1-sigma+sigma*chic)/(chic))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chic*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chic))                       ;
eqn4 = 0== -qstar + (1+r)*z1 + b2 ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [chic, z1, b1, b2]);
barchic=double(numeric_solutions.chic)


syms chic q1 z1 b1 b2 b3
eqn1 = (1+r)^3==(((1-sigma+sigma*chic)/(chic))*alpha*((q1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 + beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 + beta*sigma*alpha*mu*(((q1)^(1-eta))/(1-eta)-(q1)) ...
               + z1*chic*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chic))                       ;
eqn5 = 0== -qstar + (1+r)*z1 + b2 ;
eqn6 = 0== -q1 + z1 + b1 ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4, eqn5, eqn6 ], [chic, z1, b1, b2, b3, q1]) ;
hatchic=double(numeric_solutions.chic)



%%

ir   = xlsread('dataschi.csv',1, 'E2:E45');   ir=ir/100;
year = xlsread('dataschi.csv',1, 'A2:A45');
m1sy       = xlsread('dataschi.csv',1, 'H2:H45'); 
cy     = xlsread('dataschi.csv',1, 'I2:I45'); 
rry    = xlsread('dataschi.csv',1, 'J2:J45'); 
rratio = rry./(m1sy-cy); 

t=year;

Sqstar= (qstar^(1-eta))/(1-eta)-qstar;
for i=1:length(ir)
r=ir(i)  ;
i
chispace=linspace(0.03,0.0001,300);
for j=1:300
chi=chispace(j);
syms z1 b1 b2
eqn1 = (1+r)^2==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chi))                       ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3], [z1, b1, b2]);
z2_1=double(numeric_solutions.z1);
b2_1=double(numeric_solutions.b1);
b2_2=double(numeric_solutions.b2);
z2_2=(1+r)*z2_1;
if qstar-(b2_2+z2_2)<0
barchic=chispace(j)
    break
end
end 
chi_c_bar(i)=barchic;
end


for i=1:length(ir)
r=ir(i)  ;
i
for j=1:300
chi=chispace(j);
syms chic z1 b1 b2 b3
eqn1 = (1+r)^3==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chi))   ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [z1, b1, b2, b3]);
z3_1=double(numeric_solutions.z1);
b3_1=double(numeric_solutions.b1);
b3_2=double(numeric_solutions.b2);
b3_3=double(numeric_solutions.b3);
z3_2=(1+r)*z3_1;
z3_3=(1+r)*z3_2;

if qstar-(b3_2+z3_2)<0
hatchic=chispace(j)
    break
end
end 
chi_c_hat(i)=hatchic ;
end
%%
h=figure;
 plot(t,chi_c_bar,'r-','LineWidth',4) ; 

 hold on;
  plot(t,chi_c_hat,'b-.','LineWidth',4) ;
 hold on;
  hp=plot(t,rratio,'-','LineWidth',4) ; 
   hp.Color = [0.5 0.7 1];
legend('$\bar{\chi}_c$ (Model)','$\hat{\chi}_c$ (Model)','$\chi$ (Data)','Interpreter','latex','FontSize',15,'Location','Northeast')


%ylim([0.02 0.2])
xlim([1970 2013])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_cty','-dpdf','-r0');

%%
clc;



global target2_1 B_q

B_q=B_y/4;
target2_1=target_1*4;
r=(1+r)^(1/4)-1;
clearvars -except eta mu target_1 target_2 target_3 target2_1  target2_2 target2_3 r C chi Y_y B_y B_q;


x0= [0.01];



fun = @cali_step_2;
options = optimoptions('fsolve','Display','off');
x = fsolve(fun,x0,options);

rho=(1/0.9709)^(1/4)-1 ;
beta=1/(1+rho);



sigma_q=min(max(x(1),0),1);
alpha=(1-sigma_q) ;


B=B_q
sigma=sigma_q
q=(1+(r*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta);
q_m=q;
u=q^(1-eta)/(1-eta);
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=max(q-b,0);




target2_1
Z=z/(alpha*sigma*q+B)


nir=linspace(0.0001,0.04);  
for t=1:length(nir)
qt=real((1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta));
if eta==1
ut=log(qt);
else
ut=qt^(1-eta)/(1-eta);
end
bt=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(ut-qt)- qt*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
zt=qt-bt;
Zt(t)=zt/(alpha*sigma*qt+B);
end


lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) ;

alpha*sigma*q



qstar=1  ;
Sqstar= (qstar^(1-eta))/(1-eta)-qstar;

syms chic z1 b1 b2 q1
eqn1 = (1+r)^2==(((1-sigma+sigma*chic)/(chic))*alpha*((q1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((q1)^(1-eta))/(1-eta)-(q1)) ...
               + z1*chic*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chic))                       ;
eqn4 = 0== -qstar + (1+r)*z1 + b2 ;
eqn5 = 0== -q1 + z1 + b1 ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4, eqn5], [chic, z1, b1, b2, q1]);
barchic=double(numeric_solutions.chic)





chispace=linspace(0.05,0.0001,500);
for j=1:500
chi=chispace(j);
syms chic z1 b1 b2 b3
eqn1 = (1+r)^3==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chi))   ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [z1, b1, b2, b3]);
z3_1=double(numeric_solutions.z1);
b3_1=double(numeric_solutions.b1);
b3_2=double(numeric_solutions.b2);
b3_3=double(numeric_solutions.b3);
z3_2=(1+r)*z3_1;
z3_3=(1+r)*z3_2;

if qstar-(b3_2+z3_2)<0
hatchic=chispace(j)
    break
end
end 


%%
clearvars -except Zp1 A B  B_y C eta mu beta sigma  alpha  qstar rho target_1 target_2 target_3 avgm1 ...
    target2_1 target2_2 target2_3 avguscy elasmd ;
clc;



ir   = xlsread('dataschi.csv',1, 'E2:E45');   ir=ir/100;
year = xlsread('dataschi.csv',1, 'A2:A45');
m1sy       = xlsread('dataschi.csv',1, 'H2:H45'); 
cy     = xlsread('dataschi.csv',1, 'I2:I45'); 
rry    = xlsread('dataschi.csv',1, 'J2:J45'); 
rratio = rry./(m1sy-cy); 

t=year;
ir =(1+ir).^(1/4)-1 ;







Sqstar= (qstar^(1-eta))/(1-eta)-qstar;



for i=1:length(ir)
r=ir(i)  ;
i
chispace=linspace(0.09,0.0001,900); %600
for j=1:900
chi=chispace(j);
syms z1 b1 b2
eqn1 = (1+r)^2==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chi))                       ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3], [z1, b1, b2]);
z2_1=double(numeric_solutions.z1);
b2_1=double(numeric_solutions.b1);
b2_2=double(numeric_solutions.b2);
z2_2=(1+r)*z2_1;
if qstar-(b2_2+z2_2)<0
barchic=chispace(j)
    break
end
end 
chi_c_bar(i)=barchic;
end

chispace=linspace(0.09,0.0001,900); %400
for i=1:length(ir)
r=ir(i)  ;
i
for j=1:900
chi=chispace(j);

syms chic z1 b1 b2 b3
eqn1 = (1+r)^3==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chi))   ;
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [z1, b1, b2, b3]);
z3_1=double(numeric_solutions.z1);
b3_1=double(numeric_solutions.b1);
b3_2=double(numeric_solutions.b2);
b3_3=double(numeric_solutions.b3);
z3_2=(1+r)*z3_1;
z3_3=(1+r)*z3_2;

if qstar-(b3_2+z3_2)<0
hatchic=chispace(j)
    break
end
end 
chi_c_hat(i)=hatchic ;
end

h=figure;
 plot(t,chi_c_bar,'r-','LineWidth',4) ; 

 hold on;
  plot(t,chi_c_hat,'b-.','LineWidth',4) ;
 hold on;
  hp=plot(t,rratio,'-','LineWidth',4) ; 
   hp.Color = [0.5 0.7 1];
legend('$\bar{\chi}_c$ (Model)','$\hat{\chi}_c$ (Model)','$\chi$ (Data)','Interpreter','latex','FontSize',15,'Location','Northeast')


%ylim([0.02 0.2])
xlim([1970 2013])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'chi_ctq','-dpdf','-r0');
  

  
  