function F = cali_step_1(x)
global  B alpha sigma eta chi  r mu target_1 target_2 target_3;
rho=1/0.9709-1 ;


B=x(1);
eta=x(2);
mu=x(3);


sigma=0.5;
A=1;
alpha=A*(1-sigma) ;

q=(1+(r*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta);

dq= -chi*q^(eta+1)/(eta*alpha*(1-sigma+sigma*chi));

if eta==1
u=log(q);
else
u=q^(1-eta)/(1-eta);
end
uprime=(q^(-eta));

b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;

z=q-b;
Z=z/(alpha*sigma*q+B);


db= (mu*sigma*chi/(rho*(1-sigma+sigma*chi)) )*(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-2) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)  *( -q*(mu*sigma*chi/(rho*(1-sigma*sigma*chi))  ) )  ...
    + (1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1)* ( (mu*sigma*alpha/rho)*(uprime-1) - r*mu*alpha*sigma/(rho*(1-sigma+sigma*chi)) )*dq  ;


dz=dq-db;


dZ =dz/(alpha*sigma*q+B) -dq*(z*alpha*sigma)/(B+alpha*sigma*q)^2 ;




elasmd=dZ *(r/Z);


nir=linspace(0.0001,0.16);  
for t=1:length(nir)
qt=real((1+(nir(t)*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta));
if eta==1
ut=log(qt);
else
ut=qt^(1-eta)/(1-eta);
end
bt=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(ut-qt)- qt*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
zt=qt-bt;


Zt(t)=zt/(alpha*sigma*qt+B);
end
lognir=log(nir)';
logZt=log(Zt);
X1 = [ones(length(nir),1) lognir];
Y1=logZt ;
be_hat2= X1\Y1' ;
elasmd    = be_hat2(2) ;



avgm1=Z;


avguscy=alpha*sigma*b/(alpha*sigma*q+B);

er2_avgm1=100*(avgm1-target_1)^2      ;
er2_elasmd=100*(elasmd- target_2)^2;
er2_avguscy=100*(avguscy-target_3)^2      ;


F(1) =  avgm1   - target_1 ;

F(2) =  avguscy - target_3 ;

F(3) =  elasmd  - target_2 ;