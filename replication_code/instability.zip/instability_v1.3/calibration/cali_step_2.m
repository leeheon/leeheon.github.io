function F = cali_step_2(x)
global  B_q  sigma_q eta chi  r mu target2_1 ;


rho=(1/0.9709)^(1/4)-1 ;

sigma_q=min(max(x(1),0),1);


B=B_q;
sigma=sigma_q;



alpha=(1-sigma) ;



q=(1+(r*chi/(alpha*(1-sigma+sigma*chi))))^(-1/eta);

u=q^(1-eta)/(1-eta);
b=(1- (r*mu*sigma*chi /(rho*(1-sigma+sigma*chi))) )^(-1) * ( (mu*sigma*alpha/rho)*(u-q)- q*(r*mu*sigma*chi/(rho*(1-sigma+sigma*chi)))  ) ;
z=max(q-b,0);
Z=z/(alpha*sigma*q+B);
avgm1=Z;
Y_q=B_q+alpha*sigma*q;


F(1) =  avgm1   - target2_1 ;




