clear; clc;





r=(0.0579+1)^(1/4);
sigma = 0.071382770570630; 

alpha=1-sigma;
eta   = 0.312282094258109;
%sigma=0.5; alpha=0.5; C=1;  eta=0.9;
%sigma=0.5; alpha=0.5; C=0.8488;  eta=0.2312;


C=1;  

chi1=1;
chi2=0.5;
chi3=0.1;
chi4=0.05;

tend= 200;
zall=linspace(0.000000000001,1,tend);
zstar=1;




for k=1:tend
zt(k) =zall(k) ;
ztp0(k)=(1/r)*zt(k)*(sigma*alpha*((zt(k)+0.4)^(-eta)-1)+1);
ztp1(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi1)/(chi1))*alpha*((zt(k)+0.4)^(-eta)-1)+1);
ztp2(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha*((zt(k)+0.4)^(-eta)-1)+1);
ztp3(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi3)/(chi3))*alpha*((zt(k)+0.4)^(-eta)-1)+1);
ztp4(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi4)/(chi4))*alpha*((zt(k)+0.4)^(-eta)-1)+1);
if zt(k)+0.4>1
ztpf0(k)=(1/r)*zt(k);
ztpf1(k)=(1/r)*zt(k);
ztpf2(k)=(1/r)*zt(k);
ztpf3(k)=(1/r)*zt(k);
ztpf4(k)=(1/r)*zt(k);
else
ztpf0(k)=ztp0(k);
ztpf1(k)=ztp1(k);
ztpf2(k)=ztp2(k);
ztpf3(k)=ztp3(k);
ztpf4(k)=ztp4(k);
end
end
%
h = figure;
plot(zt,ztpf0,'k-','LineWidth',1)
hold on;
plot(zt,ztpf1,'b--','LineWidth',2)
hold on;
plot(zt,ztpf2,'g-.','LineWidth',3)
hold on;
plot(zt,ztpf3,'m:','LineWidth',3)
hold on;
plot(zt,ztpf4,'r--','LineWidth',3)

%text(0.8,1.05,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
%text(0.75,0.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('No Banking','100% Reserve Requirement','50% Reserve Requirement','10% Reserve Requirement','5% Reserve Requirement','Location','SouthEast')
ylabel('$z_{t}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{t+1}$','FontSize',13,'Interpreter','latex')
title('Calibrated Examples $(z_t,z_{t+1})$','FontSize',14,'interpreter', 'latex')
%axis([0 1.7 0 1.7])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'fq1','-dpdf','-r0')


%%

clear; clc;




rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);
r=(0.0579+1)^(1/4);
sigma = 0.071382770570630; 
mu=0.136449655111566;
alpha=1-sigma;
eta   = 0.312282094258109;
%sigma=0.5; alpha=0.5; C=1;  eta=0.9;
%sigma=0.5; alpha=0.5; C=0.8488;  eta=0.2312;


C=1;  

chi1=1;
chi2=0.5;
chi3=0.1;
chi4=0.05;

tend= 200;
ball=linspace(0.000000000001,0.7,tend);
zstar=1;





for k=1:tend
bt(k) =ball(k) ;
btp0(k)=beta*bt(k) -(1/beta)*mu*((r-1)*0.4)+beta*sigma*alpha*mu*((((bt(k)+0.4)^(1-eta))/(1-eta))-(bt(k)+0.4)) ;
btp1(k)=beta*bt(k) -(chi1/(1-sigma+sigma*chi1))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((bt(k)+0.4)^(1-eta))/(1-eta))-(bt(k)+0.4)) ;
btp2(k)=beta*bt(k) -(chi2/(1-sigma+sigma*chi2))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((bt(k)+0.4)^(1-eta))/(1-eta))-(bt(k)+0.4)) ;
btp3(k)=beta*bt(k) -(chi3/(1-sigma+sigma*chi3))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((bt(k)+0.4)^(1-eta))/(1-eta))-(bt(k)+0.4)) ;
btp4(k)=beta*bt(k) -(chi4/(1-sigma+sigma*chi4))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((bt(k)+0.4)^(1-eta))/(1-eta))-(bt(k)+0.4)) ;
if bt(k)+0.4>1
btpf0(k)=beta*bt(k) -(1/beta)*mu*((r-1)*0.4)+beta*sigma*alpha*mu*((((1)^(1-eta))/(1-eta))-(1)) ;
btpf1(k)=beta*bt(k) -(chi1/(1-sigma+sigma*chi1))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((1)^(1-eta))/(1-eta))-(1)) ;
btpf2(k)=beta*bt(k) -(chi2/(1-sigma+sigma*chi2))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((1)^(1-eta))/(1-eta))-(1)) ;
btpf3(k)=beta*bt(k) -(chi3/(1-sigma+sigma*chi3))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((1)^(1-eta))/(1-eta))-(1)) ;
btpf4(k)=beta*bt(k) -(chi4/(1-sigma+sigma*chi4))*(1/beta)*mu*sigma*((r-1)*0.4)+beta*sigma*alpha*mu*((((1)^(1-eta))/(1-eta))-(1)) ;
else
btpf0(k)=btp0(k);
btpf1(k)=btp1(k);
btpf2(k)=btp2(k);
btpf3(k)=btp3(k);
btpf4(k)=btp4(k);
end
end
%

h = figure;
plot(bt,btpf0,'k-','LineWidth',1)
hold on;
plot(bt,btpf1,'b--','LineWidth',2)
hold on;
plot(bt,btpf2,'g-.','LineWidth',3)
hold on;
plot(bt,btpf3,'m:','LineWidth',3)
hold on;
plot(bt,btpf4,'r--','LineWidth',3)

%text(0.8,1.05,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','k','FontSize',12)
%text(0.75,0.4,'$z_{t}=f(z_{t+1})$','Interpreter','latex','Color','r','FontSize',12)
legend('No Banking','100% Reserve Requirement','50% Reserve Requirement','10% Reserve Requirement','5% Reserve Requirement','Location','SouthEast')
ylabel('$b_{t}$','FontSize',13,'Interpreter','latex')
xlabel('$b_{t+1}$','FontSize',13,'Interpreter','latex')
title('Calibrated Examples $(b_t,b_{t+1})$','FontSize',14,'interpreter', 'latex')
%axis([0 1.7 0 1.7])

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'fq2','-dpdf','-r0')



