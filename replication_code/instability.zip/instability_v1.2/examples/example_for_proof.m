%% Two period cycle 1
clc;
clear;

b=0.000000000000000000000
%chi=0.5
sigma=0.6
alpha_b=0.7
A=1
theta=0.9
im=10


r=1.2
%gamma=0.75
gamma=0.8

chi=0.5
chi2=0.1



tend= 500;
zall=col_points(0,2,tend);
zstar=1
for k=1:tend
zt(k) =zall(k) ;
ztp11(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha_b*((zt(k))^(-gamma)-1)+1);
ztp12(k)=(1/r)^2*zt(k)*(((1-sigma+sigma*chi)/(chi))*alpha_b*((zt(k))^(-gamma)-1)+1);
ztp21(k)=(1/r)*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha_b*((zt(k))^(-gamma)-1)+1);
ztp22(k)=(1/r)^2*zt(k)*(((1-sigma+sigma*chi2)/(chi2))*alpha_b*((zt(k))^(-gamma)-1)+1);
if zt(k)>1
ztpf11(k)=(1/r)*zt(k);
ztpf12(k)=(1/r)^2*zt(k);
ztpf21(k)=(1/r)*zt(k);
ztpf22(k)=(1/r)^2*zt(k);
else
ztpf11(k)=ztp11(k);
ztpf12(k)=ztp12(k);
ztpf21(k)=ztp21(k);
ztpf22(k)=ztp22(k);
end
end
%%

h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztpf11,zt,'r--','LineWidth',2.5)
hold on;
plot(zt,ztpf12,'k-','LineWidth',2.5)
ylabel('$z_{2}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{1}$','FontSize',13,'Interpreter','latex')

text(0.67,1.4,'$z_{2}=f^{-1}(z_{1})$','Interpreter','latex','Color','r','FontSize',12)
text(1.4,0.88,'$z_{2}=\tilde{f}(z_{1})$','Interpreter','latex','Color','k','FontSize',12)

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'example1','-dpdf','-r0')


%%
h = figure;
plot(zt,zt,'b--','LineWidth',1)
hold on;
plot(ztpf21,zt,'r--','LineWidth',2.5)
hold on;
plot(zt,ztpf22,'k-','LineWidth',2.5)
ylabel('$z_{2}$','FontSize',13,'Interpreter','latex')
xlabel('$z_{1}$','FontSize',13,'Interpreter','latex')

text(0.67,1.4,'$z_{2}=f^{-1}(z_{1})$','Interpreter','latex','Color','r','FontSize',12)
text(1.4,0.88,'$z_{2}=\tilde{f}(z_{1})$','Interpreter','latex','Color','k','FontSize',12)
set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'example2','-dpdf','-r0')


