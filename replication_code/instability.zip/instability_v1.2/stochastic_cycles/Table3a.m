


clear; clc;

m1s       = xlsread('Book1.csv',1, 'C6:C165'); 
cpi       = xlsread('Book1.csv',1, 'D6:D165'); 
rr        = xlsread('Book1.csv',1, 'E6:E165'); 
tb3m      = xlsread('Book1.csv',1, 'F6:F165'); 
curr      = xlsread('Book1.csv',1, 'G6:G165');  

rrq=rr./(m1s-curr);

rm1s = 100*m1s./cpi ;
logrm1s=log(rm1s);
[trend_rm1s,cyclical_rm1s] = hpfilter(logrm1s);

cyclical_rm1s_70s = cyclical_rm1s(1:40)  ;
cyclical_rm1s_80s = cyclical_rm1s(41:80) ;
cyclical_rm1s_90s = cyclical_rm1s(81:120) ;
cyclical_rm1s_00s = cyclical_rm1s(121:160) ;



stdz=std(cyclical_rm1s)
stdz_70s=std(cyclical_rm1s_70s)
stdz_80s=std(cyclical_rm1s_80s)
stdz_90s=std(cyclical_rm1s_90s)
stdz_00s=std(cyclical_rm1s_00s)


mean(rrq)
mean(rrq(1:40))
mean(rrq(41:80))
mean(rrq(81:120))
mean(rrq(121:160))


tb3mm=mean(tb3m)
tb3mm_70s=mean(tb3m(1:40))
tb3mm_80s=mean(tb3m(41:80))
tb3mm_90s=mean(tb3m(81:120))
tb3mm_00s=mean(tb3m(121:160))