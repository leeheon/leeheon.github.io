%%



clear; clc;

chi=0.01;
r=(0.0579+1)-1;

sigma = 0.5; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=2.7302;
rho=(1/0.9709)-1;

beta=1/(1+rho);
qstar=(1)^(-1/eta);
Sqstar= (qstar^(1-eta))/(1-eta)-qstar;


% Define symbolic variables
syms z b

% Define the equations
eqn1 = (1+r)==(((1-sigma+sigma*chi)/(chi))*alpha*((z+b)^(-eta)-1)+1);
eqn2 = 0== -b+ beta*b +beta*sigma*alpha*mu*(((z+b)^(1-eta))/(1-eta)-(z+b)) ...
               - z*chi*mu*sigma*r/(beta*(1-sigma+sigma*chi))                       ;
numeric_solutions = vpasolve([eqn1, eqn2], [z, b]);

zss=double(numeric_solutions.z);
bss=double(numeric_solutions.b);


% Define symbolic variables
syms z1 b1 b2

% Define the equations
eqn1 = (1+r)^2==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chi))                       ;

% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3], [z1, b1, b2]);


z2_1=double(numeric_solutions.z1)
b2_1=double(numeric_solutions.b1)
b2_2=double(numeric_solutions.b2)
z2_2=(1+r)*z2_1



% Define symbolic variables
syms z1 b1 b2 b3

% Define the equations
eqn1 = (1+r)^3==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chi))   ;

% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [z1, b1, b2, b3]);

z3_1=double(numeric_solutions.z1)
b3_1=double(numeric_solutions.b1)
b3_2=double(numeric_solutions.b2)
b3_3=double(numeric_solutions.b3)
z3_2=(1+r)*z3_1
z3_3=(1+r)*z3_2



z2=[z2_1, z2_2] ;
b2=[b2_1, b2_2] ;
z3=[z3_1, z3_2, z3_3] ;
b3=[b3_1, b3_2, b3_3] ;


%{
% Define symbolic variables
syms z1 b1 b2 b3 b4

% Define the equations
eqn1 = (1+r)^4==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b4 +beta*sigma*alpha*mu*Sqstar ;
eqn5 = 0== -b4 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1))  ...
               + z1*chi*mu*sigma*(1-(1+r)^4)/(beta*(1-sigma+sigma*chi))   ;

% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4, eqn5], [z1, b1, b2, b3, b4]);


z4_1=double(numeric_solutions.z1)
b4_1=double(numeric_solutions.b1)
b4_2=double(numeric_solutions.b2)
b4_3=double(numeric_solutions.b3)
b4_4=double(numeric_solutions.b3)
z4_2=(1+r)*z4_1
z4_3=(1+r)*z4_2
z4_4=(1+r)*z4_3

%}


% Plot with filled markers using the plot function
h=figure;
plot(zss, bss, 'o', 'MarkerSize', 10, 'MarkerFaceColor', 'k'); % 'o' for circle markers, 'r' for red
hold on;
plot(z2, b2, 'd', 'MarkerSize', 10, 'MarkerFaceColor', 'r'); % 'o' for circle markers, 'r' for red
hold on;
plot(z3, b3, 's', 'MarkerSize', 13, 'MarkerFaceColor', 'b'); % 'o' for circle markers, 'b' for blue
%xlim([0.43 0.46])
% Enhancements
grid on; % Adds gridlines
xlabel('Money real balances ($z_t$)','Interpreter','latex','FontSize',15); % Label for the x-axis
ylabel('Unsecured credit ($b_t$)','Interpreter','latex','FontSize',15); % Label for the y-axis
legend('SME', '2-period cycle','3-period cycle','Interpreter','latex','FontSize',15,'Location','Northeast'); % Adds a legend
title('Endogenous Cycles with $\chi=1\%$','FontSize',15,'interpreter','latex')
set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'cycy1','-dpdf','-r0');

qstar-(b2_2+z2_2)
qstar-(b3_2+z3_2)
qstar-(b3_3+z3_3)





%%



clear; clc;

chi=0.005;
r=(0.0579+1)-1;

sigma = 0.5; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=2.7302;
rho=(1/0.9709)-1;

beta=1/(1+rho);
qstar=(1)^(-1/eta);
Sqstar= (qstar^(1-eta))/(1-eta)-qstar;

% Define symbolic variables
syms z b
% Define the equations
eqn1 = (1+r)==(((1-sigma+sigma*chi)/(chi))*alpha*((z+b)^(-eta)-1)+1);
eqn2 = 0== -b+ beta*b +beta*sigma*alpha*mu*(((z+b)^(1-eta))/(1-eta)-(z+b)) ...
               - z*chi*mu*sigma*r/(beta*(1-sigma+sigma*chi))                       ;


numeric_solutions = vpasolve([eqn1, eqn2], [z, b]);

zss=double(numeric_solutions.z);
bss=double(numeric_solutions.b);


% Define symbolic variables
syms z1 b1 b2

% Define the equations
eqn1 = (1+r)^2==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 + beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b1 + beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^2)/(beta*(1-sigma+sigma*chi))                       ;

% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3], [z1, b1, b2]);


z2_1=double(numeric_solutions.z1)
b2_1=double(numeric_solutions.b1)
b2_2=double(numeric_solutions.b2)
z2_2=(1+r)*z2_1


if z2_1+b2_1>qstar
lambda1=0;
else
lambda1=(z2_1+b2_1)^(-eta)-1 ;
end
if z2_2+b2_2>qstar
lambda2=0;
else
lambda2=(z2_2+b2_2)^(-eta)-1 ;
end
z2_2t=(z2_1/(1+r))*(((1-sigma+sigma*chi)/(chi))*alpha*lambda1+1);
z2_1t=(z2_2/(1+r))*(((1-sigma+sigma*chi)/(chi))*alpha*lambda2+1);

qstar-(b2_1+z2_1)
qstar-(b2_2+z2_2)


% Define symbolic variables
syms z1 b1 b2 b3

% Define the equations
eqn1 = (1+r)^3==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1)) ...
               + z1*chi*mu*sigma*(1-(1+r)^3)/(beta*(1-sigma+sigma*chi))   ;



% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4], [z1, b1, b2, b3]);

z3_1=double(numeric_solutions.z1)
b3_1=double(numeric_solutions.b1)
b3_2=double(numeric_solutions.b2)
b3_3=double(numeric_solutions.b3)
z3_2=(1+r)*z3_1
z3_3=(1+r)*z3_2



% Define symbolic variables
syms z1 b1 b2 b3 b4

% Define the equations
eqn1 = (1+r)^4==(((1-sigma+sigma*chi)/(chi))*alpha*((z1+b1)^(-eta)-1)+1);
eqn2 = 0== -b1 + beta*b2 +beta*sigma*alpha*mu*Sqstar ;
eqn3 = 0== -b2 + beta*b3 +beta*sigma*alpha*mu*Sqstar ;
eqn4 = 0== -b3 + beta*b4 +beta*sigma*alpha*mu*Sqstar ;
eqn5 = 0== -b4 + beta*b1 +beta*sigma*alpha*mu*(((z1+b1)^(1-eta))/(1-eta)-(z1+b1))  ...
               + z1*chi*mu*sigma*(1-(1+r)^4)/(beta*(1-sigma+sigma*chi))   ;

% Solve the system of equations
%solutions = solve([eqn1, eqn2, eqn3], [z1, b1, b2]);
% Use vpasolve to find numeric solutions
numeric_solutions = vpasolve([eqn1, eqn2, eqn3, eqn4, eqn5], [z1, b1, b2, b3, b4]);


z4_1=double(numeric_solutions.z1)
b4_1=double(numeric_solutions.b1)
b4_2=double(numeric_solutions.b2)
b4_3=double(numeric_solutions.b3)
b4_4=double(numeric_solutions.b3)
z4_2=(1+r)*z4_1
z4_3=(1+r)*z4_2
z4_4=(1+r)*z4_3

z2=[z2_1, z2_2] ;
b2=[b2_1, b2_2] ;
z3=[z3_1, z3_2, z3_3] ;
b3=[b3_1, b3_2, b3_3] ;
z4=[z4_1, z4_2, z4_3, z4_4] ;
b4=[b4_1, b4_2, b4_3, b4_4] ;


% Plot with filled markers using the plot function
h=figure;
plot(zss, bss, 'o', 'MarkerSize', 10, 'MarkerFaceColor', 'k'); % 'o' for circle markers, 'r' for red
hold on;
plot(z2, b2, 'd', 'MarkerSize', 10, 'MarkerFaceColor', 'r'); % 'o' for circle markers, 'r' for red
hold on;
plot(z3, b3, 's', 'MarkerSize', 13, 'MarkerFaceColor', 'b'); % 'o' for circle markers, 'b' for blue
hold on;
plot(z4, b4, '^', 'MarkerSize', 10, 'MarkerFaceColor', 'g'); % 'o' for circle markers, 'b' for blue
%xlim([0.43 0.46])
% Enhancements
grid on; % Adds gridlines
xlabel('Money real balances ($z_t$)','Interpreter','latex','FontSize',15); % Label for the x-axis
ylabel('Unsecured credit ($b_t$)','Interpreter','latex','FontSize',15); % Label for the y-axis
legend('SME', '2-period cycle','3-period cycle','4-period cycle','Interpreter','latex','FontSize',15,'Location','Northeast'); % Adds a legend
title('Endogenous Cycles with $\chi=0.5\%$','FontSize',15,'interpreter','latex')

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'cycy2','-dpdf','-r0');

qstar-(b2_2+z2_2)
qstar-(b3_2+z3_2)
qstar-(b3_3+z3_3)
qstar-(b4_2+z4_2)
qstar-(b4_3+z4_3)
qstar-(b4_4+z4_4)