clear; clc;




chi=0.06; 

rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);

sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;



qstar=(1)^(-1/eta);
ustar=(qstar^(1-eta))/(1-eta);

%Solve for steady state 


rf=(0.0579+1)^(1/4)-1;

qfs=((1)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta);
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*(((qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs);
zfs=qfs-bfs;





nr=rf;
gamma=(1+nr)/(1+rho);
% Set delta=t1-t0

num_iterations = 10000;
transient = 9900;


% 0.1% deviation from steady state
zt1=zfs*1.001;
bt1=bfs*1.001;



options = optimoptions('fsolve','Display','off');

x0 = [0.1,0.1];
x = fsolve(@dyn_back_solve,x0,options,zt1,bt1,qstar,nr,chi,beta,sigma,eta,alpha,mu,gamma) ;

ztv(1)=x(1);
btv(1)=x(2);
drv(1)=rf;
for t = 1:num_iterations-1
zt1=ztv(t);
bt1=btv(t);
qt1=min(qstar,zt1+bt1);
%x = fsolve(@dyn_back_solve,x0,options,zt1,bt1,qstar,nr,chi,beta,A,sigma,eta,alpha,mu,gamma) ;
zt=(zt1/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(qt1^(-eta)-1) +1) ; 

bt=beta*bt1+(chi*mu*sigma*(-gamma*zt+beta*zt1)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*((qt1^(1-eta))/(1-eta)-qt1) ; 

dr=(((1-sigma+sigma*chi)/chi)*alpha*(qt1^(-eta)-1) +1)-1 ; 

ztv(t+1)=max(real(zt),0);
btv(t+1)=max(real(bt),0);
drv(t+1)=max(real(dr),0);
    if t > transient-1
        bifurcation_z(t - transient+1) = ztv(t+1);
        bifurcation_b(t - transient+1) = btv(t+1);
        bifurcation_dr(t - transient+1) = drv(t+1);        
    end 
end
for t=1:num_iterations
tt(t)=t;
end
%{
fig1 = figure;
plot(tt, ztv(:))
fig2 = figure;
plot(tt, btv(:))
%}
for t=1:num_iterations-transient
ttb(t)=t;
end
bifurcation_z=flip(bifurcation_z);
bifurcation_b=flip(bifurcation_b);
bifurcation_dr=flip(bifurcation_dr);

bifurcation_dr=((bifurcation_dr+1).^4-1)*100;
sr(1:100, 1) = 5.79;

h= figure;
plot(ttb, sr, 'r', 'LineWidth', 1);
hold on
plot(ttb, bifurcation_dr, 'b', 'LineWidth', 1);
hold off
ylabel('Annualized Interest Rate (%)');
legend('$i$','$i_t$','Interpreter','latex','FontSize',17,'Location','Northeast')

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'drate','-dpdf','-r0')



sp1       = xlsread('fredgraph.csv',1, 'B2:B300'); 
sp2       = xlsread('fredgraph.csv',1, 'C2:C300'); 

% Define start and end dates
startDate = datetime(1984, 1, 1);
endDate   = datetime(2008, 11, 1);

% Create a vector of monthly dates
monthlyDates = startDate:calmonths(1):endDate;

% Plot the data
h=figure;
plot(monthlyDates, sp1, 'b-', 'LineWidth', 2);
hold on;
plot(monthlyDates, sp2, 'r-', 'LineWidth', 2);
grid on;

lgd=legend('Effective Fed Funds Rate - Fed Funds Target','3-Month Treasury Rate - Fed Funds Target');
lgd.FontSize = 11.5;
% Format the x-axis to show Year-Month
xtickformat('yyyy-MM');

%xlabel('Date');
ylabel('Deviation From Target (%-%)');
%title('Monthly Data from Jan 1984 to Nov 2008');

set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)])
print(h,'drated','-dpdf','-r0')