%% Money and Credit %%%  chi=0.5
clear; clc;
% Set Parameters

chi=0.5


rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);
sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;
A=1;

qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)

rf=(1.02)^(1/4)-1
ri=(1.04)^(1/4)-1 ;

%Solve for final steady state 
qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5 6 7 8 9];
%tt=[1 2 3 4 5]
%m=7
m=11;


nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1)

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt))
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3;
q=[qis qis flip(qt) qfs qfs];
b=[bis bis flip(bt) bfs bfs];
z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time]
h=figure;
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=50\%$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'news_1','-dpdf','-r0');



%% Money and Credit %%%  chi=0.1
clear
% Set Parameters

chi=0.10


rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);
sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;
A=1;

qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)


rf=(1.02)^(1/4)-1 ;
ri=(1.04)^(1/4)-1 ;

%Solve for final steady state 


qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5 6 7 8 9];
%tt=[1 2 3 4 5]
%m=7
m=11;




nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1)

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt))
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3;
q=[qis qis flip(qt) qfs qfs];
b=[bis bis flip(bt) bfs bfs];
z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time]
h=figure;
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=10\%$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'news_2','-dpdf','-r0');




%% Money and Credit %%%  chi=0.05
clear
% Set Parameters

chi=0.05


rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);
sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;
A=1;

qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)


rf=(1.02)^(1/4)-1 ;
ri=(1.04)^(1/4)-1 ;

%Solve for final steady state 
qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5 6 7 8 9];
%tt=[1 2 3 4 5]
%m=7
m=11;




nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1) ;

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)    ;
zt(tt+1)=real(zt(tt+1)) ;
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt)) ;
bt(tt+1)=real(bt(tt+1));
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3;
q=[qis qis flip(qt) qfs qfs];
b=[bis bis flip(bt) bfs bfs];
z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time]
h=figure;
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
%ylim([0.41 0.50])
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
%ylim([0.5541 0.5543])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=5\%$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'news_3','-dpdf','-r0');




%% Money and Credit %%%  chi=0.04
clear
% Set Parameters

chi=0.04;


rho=(1/0.9709)^(1/4)-1;
beta=1/(1+rho);
sigma = 0.071382770570630; 
eta   = 0.312282094258109;
alpha=1-sigma;
mu=0.136449655111566;
B=0.682544724427037;
A=1;

qstar=(1/A)^(-1/eta)
ustar=A*(qstar^(1-eta))/(1-eta)


rf=(1.02)^(1/4)-1 ;
ri=(1.04)^(1/4)-1 ;

%Solve for final steady state 
qfs=((1/A)*(1+(rf*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bfs=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-rf*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qfs^(1-eta))/(1-eta))-qfs)...
     -((rf*mu*sigma*chi)/(1-sigma+sigma*chi))*qfs)
zfs=qfs-bfs
%Solve for initial steady state 
qis=((1/A)*(1+(ri*chi/(alpha*(1-sigma+sigma*chi)))))^(-1/eta)
bis=((1-sigma+sigma*chi)/(1-sigma+sigma*chi-ri*mu*sigma*chi))*...
    (((mu*sigma*alpha)/rho)*((A*(qis^(1-eta))/(1-eta))-qis)...
     -((ri*mu*sigma*chi)/(1-sigma+sigma*chi))*qis)
zis=qis-bis


tt=[1 2 3 4 5 6 7 8 9];
%tt=[1 2 3 4 5]
%m=7
m=11;




nr=ri
gamma=(1+nr)/(1+rho)
% Set delta=t1-t0


zt(1)=(zfs/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*(qfs)^(-eta)-1) +1)
bt(1)=beta*bfs+(chi*mu*sigma*(-gamma*zt(1)+beta*zfs)/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qfs^(1-eta))/(1-eta)-qfs)



qt(1)=bt(1)+zt(1) ;

for tt=1:m
if zt(tt)<qstar
zt(tt+1)=(zt(tt)/(1+nr))*(((1-sigma+sigma*chi)/chi)*alpha*(A*qt(tt)^(-eta)-1) +1)    ;
zt(tt+1)=real(zt(tt+1)) ;
bt(tt+1)=beta*bt(tt)+(chi*mu*sigma*(-gamma*zt(tt+1)+beta*zt(tt))/(1-sigma+sigma*chi))...
       +beta*alpha*mu*sigma*(A*(qt(tt)^(1-eta))/(1-eta)-qt(tt)) ;
bt(tt+1)=real(bt(tt+1));
qt(tt+1)=bt(tt+1)+zt(tt+1)
else
zt(tt+1)=(zt(tt)/(1+nr))
bt(tt+1)=beta*bfs
qt(tt+1)=bt(tt+1)+zt(tt+1)
end
end

mn=m+3;
q=[qis qis flip(qt) qfs qfs];
b=[bis bis flip(bt) bfs bfs];
z=[zis zis flip(zt) zfs zfs];
v=length(z);
time=linspace(1,mn,mn);

time=[-1 0 time]
h=figure;
yyaxis left
plot(time,z,'-o','LineWidth',3)
ylabel('$z_t$','FontSize',15,'interpreter','latex')
%ylim([0.34 0.58])
yyaxis right
plot(time,b,'r-o','LineWidth',3)
xlim([-1 v-2])
%ylim([0.5541 0.5543])
ylabel('$b_t$','FontSize',15,'interpreter','latex')

l = legend('$z_t$','$b_t$','Location','southeast');
set(l,'FontSize',14,'interpreter', 'latex')
title('$\chi=4\%$','FontSize',14,'interpreter', 'latex')

%Reduce margin
ax = gca;
outerpos = ax.OuterPosition;
ti = ax.TightInset; 
left = outerpos(1) + ti(1);
bottom = outerpos(2) + ti(2);
ax_width = outerpos(3) - ti(1) - ti(3);
ax_height = outerpos(4) - ti(2) - ti(4);
ax.Position = [left bottom ax_width ax_height];


set(h,'Units','Inches');
pos = get(h,'Position');
set(h,'PaperPositionMode','Auto','PaperUnits','Inches','PaperSize',[pos(3), pos(4)]);
print(h,'news_4','-dpdf','-r0');
