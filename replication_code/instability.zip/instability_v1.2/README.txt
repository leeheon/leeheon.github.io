Matlab replication files for figures and numerical results in 
"On the Instability of Fractional Reserve Banking" by Heon Lee


instability_v1.2\calibration
	calibration_baseline.m: Calibration result in Table 1and Figure 6

instability_v1.2\examples
	Fig3and4.m: Figure 3 and Figure 4
	Fig5.m: Figure 5
	example_for_proof.m: Figure 18 in proof. 

instability_v1.2\endog_cycles
	Fig7a.m:Figure 7
	Fig7b.m:Figure 7
	Fig8.m:Figure 8


instability_v1.2\limit_cycles
	Fig9and10.m: Figure 9 and Figure 10
	Fig11.m: Figure 11
	Fig12.m: Figure 12
	Fig13.m: Figure 13

instability_v1.2\stochastic_cycles
	stochastic_cycles.m: Figure 14 and Figure 15
	Table3a.m: Results in Table 3
	Table3b.m: Results in Table 3

instability_v1.2\additional_results
	Fig16_1.m: Figure 16
	Fig16_2.m: Figure 16


Stata files to produce empirical analysis results

instability_v1.2\empirics
	code.do: Results in Table 4 and Figure 17

